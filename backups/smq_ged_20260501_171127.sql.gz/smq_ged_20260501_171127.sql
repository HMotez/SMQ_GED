--
-- PostgreSQL database dump
--

\restrict gUu55DN4h3FdFTto10N3tge6K6surnA9GOd7ksYM76FZEyuIYCl2RwLb5A0DvJI

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_query_logs; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.ai_query_logs (
    id integer NOT NULL,
    user_id integer,
    query_text text NOT NULL,
    intent character varying(80),
    result_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_query_logs OWNER TO smq_app;

--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.ai_query_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_query_logs_id_seq OWNER TO smq_app;

--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.ai_query_logs_id_seq OWNED BY public.ai_query_logs.id;


--
-- Name: doc_code_sequences; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.doc_code_sequences (
    type_code character varying(10) NOT NULL,
    process_code character varying(50) DEFAULT 'GLOBAL'::character varying NOT NULL,
    last_number integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.doc_code_sequences OWNER TO smq_app;

--
-- Name: document_types; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.document_types (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    label character varying(100) NOT NULL
);


ALTER TABLE public.document_types OWNER TO smq_app;

--
-- Name: document_types_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.document_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_types_id_seq OWNER TO smq_app;

--
-- Name: document_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.document_types_id_seq OWNED BY public.document_types.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    doc_code character varying(50),
    title character varying(255) NOT NULL,
    responsible character varying(255),
    next_review_date date,
    status_id integer NOT NULL,
    current_version character varying(10) DEFAULT '-'::character varying,
    folder_id integer,
    type_id integer,
    process_id integer,
    created_by integer,
    origin character varying(10) DEFAULT 'INTERNE'::character varying,
    context text,
    project_ref character varying(100),
    keywords text[],
    file_path character varying(500),
    file_name character varying(255),
    file_size bigint,
    mime_type character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.documents OWNER TO smq_app;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO smq_app;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: folders; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.folders (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    level integer DEFAULT 1 NOT NULL,
    parent_id integer
);


ALTER TABLE public.folders OWNER TO smq_app;

--
-- Name: folders_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.folders_id_seq OWNER TO smq_app;

--
-- Name: folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.folders_id_seq OWNED BY public.folders.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    document_id integer,
    action character varying(100) NOT NULL,
    user_id integer,
    details jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.logs OWNER TO smq_app;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.logs_id_seq OWNER TO smq_app;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    document_id integer,
    message text NOT NULL,
    type character varying(50) DEFAULT 'validation'::character varying NOT NULL,
    is_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO smq_app;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO smq_app;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: processes; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.processes (
    id integer NOT NULL,
    code character varying(50),
    strategic_process character varying(100),
    main_process character varying(100),
    sub_process character varying(100)
);


ALTER TABLE public.processes OWNER TO smq_app;

--
-- Name: processes_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.processes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.processes_id_seq OWNER TO smq_app;

--
-- Name: processes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.processes_id_seq OWNED BY public.processes.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(255)
);


ALTER TABLE public.roles OWNER TO smq_app;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO smq_app;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: security_incidents; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.security_incidents (
    id integer NOT NULL,
    type character varying(50) NOT NULL,
    severity character varying(16) DEFAULT 'warning'::character varying NOT NULL,
    description text NOT NULL,
    ip_address character varying(64),
    user_id integer,
    detected_at timestamp with time zone DEFAULT now(),
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    resolved_at timestamp with time zone,
    resolved_by integer,
    notes text,
    CONSTRAINT security_incidents_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT security_incidents_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying, 'resolved'::character varying])::text[])))
);


ALTER TABLE public.security_incidents OWNER TO smq_app;

--
-- Name: security_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.security_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.security_incidents_id_seq OWNER TO smq_app;

--
-- Name: security_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.security_incidents_id_seq OWNED BY public.security_incidents.id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.status (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.status OWNER TO smq_app;

--
-- Name: status_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.status_id_seq OWNER TO smq_app;

--
-- Name: status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.status_id_seq OWNED BY public.status.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    role_id integer,
    is_active boolean DEFAULT false,
    last_login timestamp with time zone,
    requested_role character varying(100),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO smq_app;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO smq_app;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: validations; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.validations (
    id integer NOT NULL,
    document_id integer NOT NULL,
    validator_id integer NOT NULL,
    validator_name character varying(255),
    validated_at timestamp with time zone DEFAULT now(),
    comment text,
    decision character varying(20) DEFAULT 'EN_ATTENTE'::character varying NOT NULL,
    version_letter character varying(5),
    signature_hash character varying(512),
    is_locked boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT validations_decision_check CHECK (((decision)::text = ANY ((ARRAY['APPROUVÉ'::character varying, 'REJETÉ'::character varying, 'EN_ATTENTE'::character varying])::text[])))
);


ALTER TABLE public.validations OWNER TO smq_app;

--
-- Name: validations_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.validations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.validations_id_seq OWNER TO smq_app;

--
-- Name: validations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.validations_id_seq OWNED BY public.validations.id;


--
-- Name: versions; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.versions (
    id integer NOT NULL,
    document_id integer NOT NULL,
    version_letter character varying(10) NOT NULL,
    file_path character varying(500),
    file_name character varying(255),
    file_size bigint,
    mime_type character varying(100),
    change_summary text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.versions OWNER TO smq_app;

--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.versions_id_seq OWNER TO smq_app;

--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.versions_id_seq OWNED BY public.versions.id;


--
-- Name: ai_query_logs id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.ai_query_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_query_logs_id_seq'::regclass);


--
-- Name: document_types id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.document_types ALTER COLUMN id SET DEFAULT nextval('public.document_types_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: folders id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.folders ALTER COLUMN id SET DEFAULT nextval('public.folders_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: processes id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.processes ALTER COLUMN id SET DEFAULT nextval('public.processes_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: security_incidents id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.security_incidents ALTER COLUMN id SET DEFAULT nextval('public.security_incidents_id_seq'::regclass);


--
-- Name: status id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.status ALTER COLUMN id SET DEFAULT nextval('public.status_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: validations id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.validations ALTER COLUMN id SET DEFAULT nextval('public.validations_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.versions ALTER COLUMN id SET DEFAULT nextval('public.versions_id_seq'::regclass);


--
-- Data for Name: ai_query_logs; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.ai_query_logs (id, user_id, query_text, intent, result_count, created_at) FROM stdin;
\.


--
-- Data for Name: doc_code_sequences; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.doc_code_sequences (type_code, process_code, last_number) FROM stdin;
\.


--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.document_types (id, code, label) FROM stdin;
1	PR	Procédures
2	IN	Instructions
3	GU	Guides
4	MN	Manuel
5	TR	Trames
6	EN	Enregistrements
7	FM	Fiches Missions
8	FF	Fiches Fonctions
9	PT	Plan de traitement
10	EX	Externe
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.documents (id, doc_code, title, responsible, next_review_date, status_id, current_version, folder_id, type_id, process_id, created_by, origin, context, project_ref, keywords, file_path, file_name, file_size, mime_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.folders (id, name, code, level, parent_id) FROM stdin;
1	01_PROCESSUS_STRATEGIQUE	01-PS	1	\N
2	02_PROCESSUS_SUPPORT	02-SP	1	\N
3	Concevoir_Developper_Produits	CDP	2	1
4	Faire_Evoluer_Securiser_SI	FESI	2	1
5	Fournir_Prestations_Service	FPS	2	1
6	Gerer_Infrastructure_Environnement_Travail	GIET	2	1
7	Maitriser_Achats_Logistique	MAL	2	2
8	Manager_Sante_Securite_Travail	MSST	2	2
9	Manager_Motiver_Ressources	MMR	2	2
10	Piloter_l_Entreprise	PE	2	2
11	PS_Processus_Strategique	CDP-PS	3	3
12	PM_Conception_Mecanique	CDP-MC	3	3
13	PM_Conception_Developpement_Logiciel	CDP-DL	3	3
14	PM_Conception_Developpement_Outillages	CDP-DO	3	3
15	PM_Electronique	CDP-EL	3	3
16	PM_Qualification_Thermomecanique	CDP-QT	3	3
17	PM_Validation	CDP-VA	3	3
18	PM_Industrialisation_Vie_Serie	CDP-IVS	3	3
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.logs (id, document_id, action, user_id, details, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.notifications (id, user_id, document_id, message, type, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: processes; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.processes (id, code, strategic_process, main_process, sub_process) FROM stdin;
1	CDP	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	Concevoir_Developper_Produits
2	FESI	01_PROCESSUS_STRATEGIQUE	Faire_Evoluer_Securiser_SI	Faire_Evoluer_Securiser_SI
3	FPS	01_PROCESSUS_STRATEGIQUE	Fournir_Prestations_Service	Fournir_Prestations_Service
4	GIET	01_PROCESSUS_STRATEGIQUE	Gerer_Infrastructure_Environnement_Travail	Gerer_Infrastructure_Environnement_Travail
5	MAL	02_PROCESSUS_SUPPORT	Maitriser_Achats_Logistique	Maitriser_Achats_Logistique
6	MSST	02_PROCESSUS_SUPPORT	Manager_Sante_Securite_Travail	Manager_Sante_Securite_Travail
7	MMR	02_PROCESSUS_SUPPORT	Manager_Motiver_Ressources	Manager_Motiver_Ressources
8	PE	02_PROCESSUS_SUPPORT	Piloter_l_Entreprise	Piloter_l_Entreprise
9	CDP-PS	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PS_Processus_Strategique
10	CDP-MC	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Mecanique
11	CDP-DL	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Developpement_Logiciel
12	CDP-DO	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Developpement_Outillages
13	CDP-EL	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Electronique
14	CDP-QT	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Qualification_Thermomecanique
15	CDP-VA	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Validation
16	CDP-IVS	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Industrialisation_Vie_Serie
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.roles (id, name, description) FROM stdin;
\.


--
-- Data for Name: security_incidents; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.security_incidents (id, type, severity, description, ip_address, user_id, detected_at, status, resolved_at, resolved_by, notes) FROM stdin;
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.status (id, name) FROM stdin;
1	Brouillon
2	En rédaction
3	En relecture
4	En validation
5	Validé
6	Diffusé
7	Obsolète
8	Archivé
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.users (id, name, email, password_hash, role_id, is_active, last_login, requested_role, created_at) FROM stdin;
\.


--
-- Data for Name: validations; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.validations (id, document_id, validator_id, validator_name, validated_at, comment, decision, version_letter, signature_hash, is_locked, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.versions (id, document_id, version_letter, file_path, file_name, file_size, mime_type, change_summary, created_at) FROM stdin;
\.


--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.ai_query_logs_id_seq', 1, false);


--
-- Name: document_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.document_types_id_seq', 10, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.folders_id_seq', 18, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.logs_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.processes_id_seq', 16, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: security_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.security_incidents_id_seq', 1, false);


--
-- Name: status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.status_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: validations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.validations_id_seq', 1, false);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.versions_id_seq', 1, false);


--
-- Name: ai_query_logs ai_query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_pkey PRIMARY KEY (id);


--
-- Name: doc_code_sequences doc_code_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.doc_code_sequences
    ADD CONSTRAINT doc_code_sequences_pkey PRIMARY KEY (type_code, process_code);


--
-- Name: document_types document_types_code_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_code_key UNIQUE (code);


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);


--
-- Name: documents documents_doc_code_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_doc_code_key UNIQUE (doc_code);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: processes processes_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.processes
    ADD CONSTRAINT processes_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: security_incidents security_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_pkey PRIMARY KEY (id);


--
-- Name: status status_name_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_name_key UNIQUE (name);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: validations validations_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_logs_created; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_ai_logs_created ON public.ai_query_logs USING btree (created_at DESC);


--
-- Name: idx_ai_logs_user; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_ai_logs_user ON public.ai_query_logs USING btree (user_id);


--
-- Name: idx_incidents_detected_at; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_incidents_detected_at ON public.security_incidents USING btree (detected_at DESC);


--
-- Name: idx_incidents_severity; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_incidents_severity ON public.security_incidents USING btree (severity);


--
-- Name: idx_incidents_status; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_incidents_status ON public.security_incidents USING btree (status);


--
-- Name: idx_notif_unread; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_notif_unread ON public.notifications USING btree (user_id, is_read);


--
-- Name: idx_notif_user_id; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_notif_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_validations_decision; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_validations_decision ON public.validations USING btree (decision);


--
-- Name: idx_validations_document_id; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_validations_document_id ON public.validations USING btree (document_id);


--
-- Name: idx_validations_validator_id; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_validations_validator_id ON public.validations USING btree (validator_id);


--
-- Name: ai_query_logs ai_query_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- Name: documents documents_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: documents documents_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.document_types(id);


--
-- Name: folders folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.folders(id) ON DELETE CASCADE;


--
-- Name: logs logs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: logs logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: security_incidents security_incidents_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: security_incidents security_incidents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: validations validations_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: validations validations_validator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_validator_id_fkey FOREIGN KEY (validator_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: versions versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO smq_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO smq_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO smq_app;


--
-- PostgreSQL database dump complete
--

\unrestrict gUu55DN4h3FdFTto10N3tge6K6surnA9GOd7ksYM76FZEyuIYCl2RwLb5A0DvJI

