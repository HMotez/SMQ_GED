--
-- PostgreSQL database dump
--

\restrict 4yc7S8OTKo3OCN134kaihDo0I0WVbM9u46pawHul2nx0sAk998fZzKme77cScsJ

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_query_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_query_logs (
    id integer NOT NULL,
    user_id integer,
    query_text text NOT NULL,
    intent character varying(80),
    result_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_query_logs OWNER TO postgres;

--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_query_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_query_logs_id_seq OWNER TO postgres;

--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_query_logs_id_seq OWNED BY public.ai_query_logs.id;


--
-- Name: doc_code_sequences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doc_code_sequences (
    type_code character varying(10) NOT NULL,
    process_code character varying(50) DEFAULT 'GLOBAL'::character varying NOT NULL,
    last_number integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.doc_code_sequences OWNER TO postgres;

--
-- Name: document_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_types (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    label character varying(100) NOT NULL
);


ALTER TABLE public.document_types OWNER TO postgres;

--
-- Name: document_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.document_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_types_id_seq OWNER TO postgres;

--
-- Name: document_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.document_types_id_seq OWNED BY public.document_types.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    doc_code character varying(50),
    title character varying(255) NOT NULL,
    responsible character varying(255),
    next_review_date date,
    status_id integer NOT NULL,
    current_version character varying(10) DEFAULT '-'::character varying,
    folder_id integer,
    type_id integer,
    process_id integer,
    created_by integer,
    origin character varying(10) DEFAULT 'INTERNE'::character varying,
    context text,
    project_ref character varying(100),
    keywords text[],
    file_path character varying(500),
    file_name character varying(255),
    file_size bigint,
    mime_type character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    sharepoint_link character varying(500),
    validated_version character varying(10)
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: folders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.folders (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    level integer DEFAULT 1 NOT NULL,
    parent_id integer
);


ALTER TABLE public.folders OWNER TO postgres;

--
-- Name: folders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.folders_id_seq OWNER TO postgres;

--
-- Name: folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.folders_id_seq OWNED BY public.folders.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    document_id integer,
    action character varying(100) NOT NULL,
    user_id integer,
    details jsonb,
    created_at timestamp with time zone DEFAULT now(),
    ip_address character varying(64),
    user_agent text,
    severity character varying(16) DEFAULT 'info'::character varying NOT NULL,
    CONSTRAINT logs_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.logs OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.logs_id_seq OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    document_id integer,
    message text NOT NULL,
    type character varying(50) DEFAULT 'validation'::character varying NOT NULL,
    is_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: processes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.processes (
    id integer NOT NULL,
    code character varying(50),
    strategic_process character varying(100),
    main_process character varying(100),
    sub_process character varying(100)
);


ALTER TABLE public.processes OWNER TO postgres;

--
-- Name: processes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.processes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.processes_id_seq OWNER TO postgres;

--
-- Name: processes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.processes_id_seq OWNED BY public.processes.id;


--
-- Name: reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reset_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token character varying(128) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.reset_tokens OWNER TO postgres;

--
-- Name: reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reset_tokens_id_seq OWNER TO postgres;

--
-- Name: reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reset_tokens_id_seq OWNED BY public.reset_tokens.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(255)
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: security_incidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.security_incidents (
    id integer NOT NULL,
    type character varying(50) NOT NULL,
    severity character varying(16) DEFAULT 'warning'::character varying NOT NULL,
    description text NOT NULL,
    ip_address character varying(64),
    user_id integer,
    detected_at timestamp with time zone DEFAULT now(),
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    resolved_at timestamp with time zone,
    resolved_by integer,
    notes text,
    CONSTRAINT security_incidents_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT security_incidents_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying, 'resolved'::character varying])::text[])))
);


ALTER TABLE public.security_incidents OWNER TO postgres;

--
-- Name: security_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.security_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.security_incidents_id_seq OWNER TO postgres;

--
-- Name: security_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.security_incidents_id_seq OWNED BY public.security_incidents.id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.status_id_seq OWNER TO postgres;

--
-- Name: status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_id_seq OWNED BY public.status.id;


--
-- Name: token_blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.token_blacklist (
    jti character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    token_hash character varying(64)
);


ALTER TABLE public.token_blacklist OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    role_id integer,
    is_active boolean DEFAULT false,
    last_login timestamp with time zone,
    requested_role character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    failed_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_activity timestamp with time zone,
    login_attempts integer DEFAULT 0,
    last_login_ip character varying(64)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: validations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.validations (
    id integer NOT NULL,
    document_id integer NOT NULL,
    validator_id integer NOT NULL,
    validator_name character varying(255),
    validated_at timestamp with time zone DEFAULT now(),
    comment text,
    decision character varying(20) DEFAULT 'EN_ATTENTE'::character varying NOT NULL,
    version_letter character varying(5),
    signature_hash character varying(512),
    is_locked boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT check_locked_immutable CHECK ((is_locked = true)),
    CONSTRAINT validations_decision_check CHECK (((decision)::text = ANY ((ARRAY['APPROUVÉ'::character varying, 'REJETÉ'::character varying, 'EN_ATTENTE'::character varying])::text[])))
);


ALTER TABLE public.validations OWNER TO postgres;

--
-- Name: validations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.validations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.validations_id_seq OWNER TO postgres;

--
-- Name: validations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.validations_id_seq OWNED BY public.validations.id;


--
-- Name: versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.versions (
    id integer NOT NULL,
    document_id integer NOT NULL,
    version_letter character varying(10) NOT NULL,
    file_path character varying(500),
    file_name character varying(255),
    file_size bigint,
    mime_type character varying(100),
    change_summary text,
    created_at timestamp with time zone DEFAULT now(),
    sharepoint_link character varying(500)
);


ALTER TABLE public.versions OWNER TO postgres;

--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.versions_id_seq OWNER TO postgres;

--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.versions_id_seq OWNED BY public.versions.id;


--
-- Name: ai_query_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_query_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_query_logs_id_seq'::regclass);


--
-- Name: document_types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_types ALTER COLUMN id SET DEFAULT nextval('public.document_types_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: folders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders ALTER COLUMN id SET DEFAULT nextval('public.folders_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: processes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processes ALTER COLUMN id SET DEFAULT nextval('public.processes_id_seq'::regclass);


--
-- Name: reset_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.reset_tokens_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: security_incidents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents ALTER COLUMN id SET DEFAULT nextval('public.security_incidents_id_seq'::regclass);


--
-- Name: status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status ALTER COLUMN id SET DEFAULT nextval('public.status_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: validations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations ALTER COLUMN id SET DEFAULT nextval('public.validations_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.versions ALTER COLUMN id SET DEFAULT nextval('public.versions_id_seq'::regclass);


--
-- Data for Name: ai_query_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_query_logs (id, user_id, query_text, intent, result_count, created_at) FROM stdin;
1	\N	Quels documents n'ont jamais été consultés ?	activity_logs	0	2026-04-17 16:22:15.580795+00
2	\N	Quels documents ont dépassé leur date de révision ?	expired_docs	4	2026-04-17 16:22:22.621536+00
3	1	bonjour	help	0	2026-04-22 19:58:57.995458+00
4	1	Comment puis-je vous aider avec les documents en cours ?	by_type	0	2026-04-22 19:59:24.129607+00
5	1	Quels documents sont en cours de relecture ?	in_relecture	1	2026-04-22 19:59:52.198333+00
6	1	Combien de documents par type documentaire ?	by_type	0	2026-04-22 20:00:06.806189+00
7	1	Bonjour ! Je suis votre assistant IA propulsé par **Groq AI** (Llama 3.3 70B). Posez-moi n'importe quelle question — sur vos documents, l'ISO 9001, la qualité, ou n'importe quel autre sujet. Je suis là pour vous aider !	help	0	2026-04-22 20:04:09.250304+00
\.


--
-- Data for Name: doc_code_sequences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doc_code_sequences (type_code, process_code, last_number) FROM stdin;
PR	GLOBAL	3
TR	GLOBAL	4
GU	GLOBAL	3
IN	GLOBAL	2
\.


--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_types (id, code, label) FROM stdin;
1	PR	Procédures
2	IN	Instructions
3	GU	Guides
4	MN	Manuel
5	TR	Trames
6	EN	Enregistrements
7	FM	Fiches Missions
8	FF	Fiches Fonctions
9	PT	Plan de traitement
10	EX	Externe
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, doc_code, title, responsible, next_review_date, status_id, current_version, folder_id, type_id, process_id, created_by, origin, context, project_ref, keywords, file_path, file_name, file_size, mime_type, created_at, updated_at, sharepoint_link, validated_version) FROM stdin;
1	PR0001_Procedure_-	Procédure	Moetez	2026-01-20	3	-	39	1	6	1	INTERNE	\N	\N	\N	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_de_Travail/PR_Procedures/PR0001_Procedure_-.pdf	PR0001_Procedure_-.pdf	\N	application/pdf	2026-04-17 14:46:30.041727+00	2026-04-17 14:46:30.041727+00	\N	\N
2	PR0002_Procedure_-	Procédure	Moetez	2026-03-28	1	-	13	1	3	1	INTERNE	\N	\N	\N	01_PROCESSUS_STRATEGIQUE/Concevoir_Developper_Produits/PM_Processus_Metiers/PM_Conception_Developpement_Logiciel/PR0002_Procedure_-.pdf	PR0002_Procedure_-.pdf	\N	application/pdf	2026-04-17 14:46:30.041727+00	2026-04-17 14:46:30.041727+00	\N	\N
4	GU0001_Guide_vA1	Guide	Alison	2026-06-11	8	vA1	41	3	6	1	INTERNE	\N	\N	\N	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_de_Travail/GU_Guides/GU0001_Guide_vA1.pdf	GU0001_Guide_vA1.pdf	\N	application/pdf	2026-04-17 14:46:30.041727+00	2026-04-17 14:46:30.041727+00	\N	\N
6	TR0001_Trame_-	Trame	Moetez	2026-04-29	4	-	47	5	7	1	INTERNE	\N	\N	\N	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/TR_Trames/TR0001_Trame_-.pdf	TR0001_Trame_-.pdf	\N	application/pdf	2026-04-17 14:46:30.041727+00	2026-04-17 14:46:30.041727+00	\N	\N
7	TR0002_Trame_vA1	Trame	Moetez	2026-01-16	8	vA1	47	5	7	1	INTERNE	\N	\N	\N	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/TR_Trames/TR0002_Trame_vA1.pdf	TR0002_Trame_vA1.pdf	\N	application/pdf	2026-04-17 14:46:30.041727+00	2026-04-17 14:46:30.041727+00	\N	\N
9	IN0001_Instruction_vA2	Instruction	Moetez	2026-04-02	5	vA2	64	2	10	1	INTERNE	\N	\N	\N	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/IN_Instructions/IN0001_Instruction_vA2.pdf	IN0001_Instruction_vA2.pdf	\N	application/pdf	2026-04-17 14:46:30.041727+00	2026-04-17 14:46:30.041727+00	\N	\N
5	GU0002_Guide_vA	Guide	Moetez	2026-04-17	1	vA	46	3	7	1	INTERNE	\N	\N	\N	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/GU_Guides/GU0002_Guide_vA.pdf	GU0002_Guide_vA.pdf	110471	application/pdf	2026-04-17 14:46:30.041727+00	2026-04-17 14:46:30.041727+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=CWnG7M	\N
12	IN0002_Instruction_-	Instruction	Alison	2026-05-28	1	v-	13	2	13	1	INTERNE	PROCESSUS	\N	{in}	01_PROCESSUS_STRATEGIQUE/Concevoir_Developper_Produits/PM_Processus_Metiers/PM_Conception_Developpement_Logiciel/IN0002_Instruction_-.pdf	IN0002_Instruction_-.pdf	110471	application/pdf	2026-04-18 20:56:03.617186+00	2026-04-18 20:56:03.617186+00	\N	\N
11	GU0003_Guide_vA	Guide	Moetez	2026-05-01	1	vA	46	3	46	\N	INTERNE	PROJET	\N	{gu}	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/GU_Guides/GU0003_Guide_vA.pdf	GU0003_Guide_vA.pdf	110471	application/pdf	2026-04-17 16:36:34.52227+00	2026-04-17 16:36:34.52227+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=mZxNTq	\N
3	PR0003_Procedure_vA	Procédure	Moetez	2026-06-19	1	vA	39	1	6	1	INTERNE	\N	\N	\N	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_Travail/PR_Procedures/PR0003_Procedure_vA.pdf	PR0003_Procedure_vA.pdf	110471	application/pdf	2026-04-17 14:46:30.041727+00	2026-04-17 14:46:30.041727+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=VoeW6f	\N
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.folders (id, name, code, level, parent_id) FROM stdin;
1	01_PROCESSUS_STRATEGIQUE	01-PS	1	\N
2	02_PROCESSUS_SUPPORT	02-SP	1	\N
3	Concevoir_Developper_Produits	CDP	2	1
4	Faire_Evoluer_Securiser_SI	FESI	2	1
5	Fournir_Prestations_Service	FPS	2	1
6	Gerer_Infrastructure_Environnement_Travail	GIET	2	1
7	Maitriser_Achats_Logistique	MAL	2	2
8	Manager_Sante_Securite_Travail	MSST	2	2
9	Manager_Motiver_Ressources	MMR	2	2
10	Piloter_l_Entreprise	PE	2	2
11	PS_Processus_Strategique	CDP-PS	3	3
19	TR_Trames	FESI-TR	3	4
20	IN_Instructions	GIET-IN	3	6
21	GU_Guides	MAL-GU	3	7
22	IN_Instructions	MAL-IN	3	7
23	PM_Processus_Metiers	CDP-PM	3	3
12	PM_Conception_Mecanique	CDP-MC	4	23
13	PM_Conception_Developpement_Logiciel	CDP-DL	4	23
14	PM_Conception_Developpement_Outillages	CDP-DO	4	23
15	PM_Electronique	CDP-EL	4	23
16	PM_Qualification_Thermomecanique	CDP-QT	4	23
17	PM_Validation	CDP-VA	4	23
18	PM_Industrialisation_Vie_Serie	CDP-IVS	4	23
24	PR_Procedures	CDP-PS-PR	4	11
25	IN_Instructions	CDP-PS-IN	4	11
26	GU_Guides	CDP-PS-GU	4	11
27	TR_Trames	CDP-PS-TR	4	11
28	EN_Enregistrements	CDP-PS-EN	4	11
29	PR_Procedures	FESI-PR	3	4
30	IN_Instructions	FESI-IN	3	4
31	GU_Guides	FESI-GU	3	4
32	TR_Trames	FESI-TR	3	4
33	EN_Enregistrements	FESI-EN	3	4
34	PR_Procedures	FPS-PR	3	5
35	IN_Instructions	FPS-IN	3	5
36	GU_Guides	FPS-GU	3	5
37	TR_Trames	FPS-TR	3	5
38	EN_Enregistrements	FPS-EN	3	5
39	PR_Procedures	GIET-PR	3	6
40	IN_Instructions	GIET-IN	3	6
41	GU_Guides	GIET-GU	3	6
42	TR_Trames	GIET-TR	3	6
43	EN_Enregistrements	GIET-EN	3	6
44	PR_Procedures	MAL-PR	3	7
45	IN_Instructions	MAL-IN	3	7
46	GU_Guides	MAL-GU	3	7
47	TR_Trames	MAL-TR	3	7
48	EN_Enregistrements	MAL-EN	3	7
49	PR_Procedures	MSST-PR	3	8
50	IN_Instructions	MSST-IN	3	8
51	GU_Guides	MSST-GU	3	8
52	TR_Trames	MSST-TR	3	8
53	EN_Enregistrements	MSST-EN	3	8
54	FF_Fiches_Fonctions	MMR-FF	3	9
55	FM_Fiches_Missions	MMR-FM	3	9
56	PR_Procedures	MMR-PR	3	9
57	IN_Instructions	MMR-IN	3	9
58	GU_Guides	MMR-GU	3	9
59	TR_Trames	MMR-TR	3	9
60	EN_Enregistrements	MMR-EN	3	9
61	FF_Fiches_Fonctions	PE-FF	3	10
62	FM_Fiches_Missions	PE-FM	3	10
63	PR_Procedures	PE-PR	3	10
64	IN_Instructions	PE-IN	3	10
65	GU_Guides	PE-GU	3	10
66	TR_Trames	PE-TR	3	10
67	EN_Enregistrements	PE-EN	3	10
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logs (id, document_id, action, user_id, details, created_at, ip_address, user_agent, severity) FROM stdin;
1	10	CREATE_DOCUMENT	1	{"origin": "INTERNE", "doc_code": "TR0004_Trame_-", "typeCode": "TR", "folderCode": "PE-TR"}	2026-04-17 15:32:01.613229+00	\N	\N	info
7	1	CREATE_DOCUMENT	1	{"origin": "INTERNE", "typeCode": "PR", "folderCode": "GIET-PR"}	2026-04-17 14:46:30.041727+00	\N	\N	info
8	3	CREATE_DOCUMENT	1	{"origin": "INTERNE", "typeCode": "PR", "folderCode": "GIET-PR"}	2026-04-17 14:46:30.041727+00	\N	\N	info
9	2	CREATE_DOCUMENT	1	{"origin": "INTERNE", "typeCode": "PR", "folderCode": "CDP-DL"}	2026-04-17 14:46:30.041727+00	\N	\N	info
10	9	CREATE_DOCUMENT	1	{"origin": "INTERNE", "typeCode": "IN", "folderCode": "PE-IN"}	2026-04-17 14:46:30.041727+00	\N	\N	info
11	5	CREATE_DOCUMENT	1	{"origin": "INTERNE", "typeCode": "GU", "folderCode": "MAL-GU"}	2026-04-17 14:46:30.041727+00	\N	\N	info
12	4	CREATE_DOCUMENT	1	{"origin": "INTERNE", "typeCode": "GU", "folderCode": "GIET-GU"}	2026-04-17 14:46:30.041727+00	\N	\N	info
13	6	CREATE_DOCUMENT	1	{"origin": "INTERNE", "typeCode": "TR", "folderCode": "MAL-TR"}	2026-04-17 14:46:30.041727+00	\N	\N	info
14	7	CREATE_DOCUMENT	1	{"origin": "INTERNE", "typeCode": "TR", "folderCode": "MAL-TR"}	2026-04-17 14:46:30.041727+00	\N	\N	info
15	1	STATUS_CHANGE	1	{"to": "En relecture", "from": "Brouillon"}	2026-04-17 14:47:30.041727+00	\N	\N	info
16	6	STATUS_CHANGE	1	{"to": "En validation", "from": "Brouillon"}	2026-04-17 14:47:30.041727+00	\N	\N	info
17	7	STATUS_CHANGE	1	{"to": "Archivé", "from": "Brouillon"}	2026-04-17 14:47:30.041727+00	\N	\N	info
18	4	STATUS_CHANGE	1	{"to": "Archivé", "from": "Brouillon"}	2026-04-17 14:47:30.041727+00	\N	\N	info
20	5	NEW_VERSION	\N	{"to": "vA", "from": "-", "change_summary": "tttt"}	2026-04-17 16:37:26.070885+00	\N	\N	info
19	11	CREATE_DOCUMENT	\N	{"origin": "INTERNE", "doc_code": "GU0003_Guide_-", "typeCode": "GU", "folderCode": "MAL-GU"}	2026-04-17 16:36:34.52227+00	\N	\N	info
21	12	CREATE_DOCUMENT	1	{"origin": "INTERNE", "doc_code": "IN0002_Instruction_-", "typeCode": "IN", "folderCode": "CDP-DL"}	2026-04-18 20:56:03.617186+00	\N	\N	info
22	11	VERSION_SUPERSEDED	\N	{"reason": "Remplacée par une nouvelle version", "doc_code": "GU0003_Guide_-", "new_version": "vA", "superseded_version": "v-"}	2026-04-22 19:57:01.155068+00	\N	\N	info
23	11	NEW_VERSION	\N	{"to": "vA", "from": "v-", "change_summary": "test"}	2026-04-22 19:57:01.155068+00	\N	\N	info
24	\N	LOGIN_SUCCESS	1	{"ip": "172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-04-23 21:17:21.558871+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
25	3	NEW_VERSION	\N	{"to": "vA", "from": "-", "change_summary": "test v"}	2026-04-23 21:18:04.318168+00	\N	\N	info
26	\N	ACCESS_DENIED_401	\N	{"path": "/api/ai/improvements", "method": "GET"}	2026-04-24 10:26:51.018863+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	warning
27	\N	LOGIN_SUCCESS	1	{"ip": "172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-04-24 10:27:16.024664+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
28	\N	LOGIN_SUCCESS	1	{"ip": "172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-04-24 10:44:04.818887+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
29	\N	LOGIN_SUCCESS	2	{"ip": "172.18.0.1", "role": "Ing. Qualité", "email": "ing@test.com"}	2026-04-24 13:12:21.311452+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, document_id, message, type, is_read, created_at) FROM stdin;
1	1	7	Document TR0002_Trame_vA1 — date de revue dépassée (16/01/2026)	expiration	f	2026-04-17 15:37:36.369748+00
4	1	9	Document IN0001_Instruction_vA2 — revue proche (02/04/2026)	expiration	f	2026-04-17 15:37:36.369748+00
5	2	1	Document PR0001_Procedure_- — en attente de votre relecture	status	f	2026-04-17 15:37:36.369748+00
6	2	6	Document TR0001_Trame_- — en attente de validation	status	f	2026-04-17 15:37:36.369748+00
7	3	6	Document TR0001_Trame_- — soumis pour validation	status	f	2026-04-17 15:37:36.369748+00
8	1	5	[GU0002_Guide_-] "Guide" — date de révision dépassée depuis 0 jour(s) (prévue le 17/04/2026). Une révision est requise.	expiration	f	2026-04-17 15:39:00.74601+00
16	2	5	[GU0002_Guide_-] "Guide" — nouvelle version (vvA) créée par Admin (Admin). Résumé : "tttt".	version	f	2026-04-17 16:37:26.138359+00
13	1	5	[GU0002_Guide_-] "Guide" — nouvelle version (vvA) créée par Admin (Admin). Résumé : "tttt".	version	t	2026-04-17 16:37:26.123674+00
3	1	2	Document PR0002_Procedure_- — date de revue dépassée (28/03/2026)	expiration	t	2026-04-17 15:37:36.369748+00
2	1	1	Document PR0001_Procedure_- — date de revue dépassée (20/01/2026)	expiration	t	2026-04-17 15:37:36.369748+00
17	1	2	[PR0002_Procedure_-] "Procédure" — date de révision dépassée depuis 20 jour(s) (prévue le 28/03/2026). Une révision est requise.	expiration	f	2026-04-17 18:14:47.287606+00
18	1	1	[PR0001_Procedure_-] "Procédure" — date de révision dépassée depuis 87 jour(s) (prévue le 20/01/2026). Une révision est requise.	expiration	f	2026-04-17 18:14:47.293172+00
23	1	11	[GU0003_Guide_-] "Guide" — nouvelle version (vv- → vvA) créée par Admin (Admin). Résumé : "test".	version	f	2026-04-22 19:57:01.31103+00
26	2	11	[GU0003_Guide_-] "Guide" — nouvelle version (vv- → vvA) créée par Admin (Admin). Résumé : "test".	version	f	2026-04-22 19:57:01.345038+00
27	1	3	[PR0003_Procedure_-] "Procédure" — nouvelle version (vvA) créée par Admin (Admin). Résumé : "test v".	version	f	2026-04-23 21:18:04.572699+00
30	2	3	[PR0003_Procedure_-] "Procédure" — nouvelle version (vvA) créée par Admin (Admin). Résumé : "test v".	version	f	2026-04-23 21:18:04.603014+00
31	20	5	[GU0002_Guide_vA] "Guide" — date de révision dépassée depuis 7 jour(s) (prévue le 17/04/2026). Une révision est requise.	expiration	f	2026-04-24 10:45:40.393665+00
32	20	2	[PR0002_Procedure_-] "Procédure" — date de révision dépassée depuis 27 jour(s) (prévue le 28/03/2026). Une révision est requise.	expiration	f	2026-04-24 10:45:40.399618+00
33	20	1	[PR0001_Procedure_-] "Procédure" — date de révision dépassée depuis 94 jour(s) (prévue le 20/01/2026). Une révision est requise.	expiration	f	2026-04-24 10:45:40.402565+00
34	20	9	[IN0001_Instruction_vA2] "Instruction" — date de révision dépassée depuis 22 jour(s) (prévue le 02/04/2026). Une révision est requise.	expiration	f	2026-04-24 10:45:40.405063+00
\.


--
-- Data for Name: processes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.processes (id, code, strategic_process, main_process, sub_process) FROM stdin;
1	CDP	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	Concevoir_Developper_Produits
2	FESI	01_PROCESSUS_STRATEGIQUE	Faire_Evoluer_Securiser_SI	Faire_Evoluer_Securiser_SI
3	FPS	01_PROCESSUS_STRATEGIQUE	Fournir_Prestations_Service	Fournir_Prestations_Service
4	GIET	01_PROCESSUS_STRATEGIQUE	Gerer_Infrastructure_Environnement_Travail	Gerer_Infrastructure_Environnement_Travail
5	MAL	02_PROCESSUS_SUPPORT	Maitriser_Achats_Logistique	Maitriser_Achats_Logistique
6	MSST	02_PROCESSUS_SUPPORT	Manager_Sante_Securite_Travail	Manager_Sante_Securite_Travail
7	MMR	02_PROCESSUS_SUPPORT	Manager_Motiver_Ressources	Manager_Motiver_Ressources
8	PE	02_PROCESSUS_SUPPORT	Piloter_l_Entreprise	Piloter_l_Entreprise
9	CDP-PS	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PS_Processus_Strategique
10	CDP-MC	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Mecanique
11	CDP-DL	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Developpement_Logiciel
12	CDP-DO	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Developpement_Outillages
13	CDP-EL	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Electronique
14	CDP-QT	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Qualification_Thermomecanique
15	CDP-VA	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Validation
16	CDP-IVS	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Industrialisation_Vie_Serie
\.


--
-- Data for Name: reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reset_tokens (id, user_id, token, expires_at, used, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description) FROM stdin;
1	Admin	Accès complet — gestion utilisateurs, archivage, workflow
2	Ing. Qualité	Création, modification et soumission de documents
3	Reviewer	Relecture et validation des documents
\.


--
-- Data for Name: security_incidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.security_incidents (id, type, severity, description, ip_address, user_id, detected_at, status, resolved_at, resolved_by, notes) FROM stdin;
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status (id, name) FROM stdin;
1	Brouillon
2	En rédaction
3	En relecture
4	En validation
5	Validé
6	Diffusé
7	Obsolète
8	Archivé
9	Appel en relecture
10	En correction
\.


--
-- Data for Name: token_blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.token_blacklist (jti, expires_at, created_at, token_hash) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, password_hash, role_id, is_active, last_login, requested_role, created_at, failed_attempts, locked_until, last_activity, login_attempts, last_login_ip) FROM stdin;
3	Reviewer	reviewer@test.com	$2b$10$UyysGfoL3IICw2PYyDDTJ.W1bP3Ffl1Hy.tDTkP0sdyLxhcdJI8uW	3	t	2026-04-22 20:08:10.440415+00	\N	2026-04-17 14:28:17.8471+00	2	\N	\N	0	172.18.0.1
19	Alison	alison@test.com	$2b$10$2CmO4jPdkbcnit13N7gCLOzoRw3uJk4iZgnQ7GBqnufidfzk.B/xy	\N	f	\N	Reviewer	2026-04-24 10:43:48.916454+00	0	\N	\N	0	\N
1	Admin	admin@test.com	$2b$10$JDgTxDiWttyrBXVqxUZpRu1T8SYocYSpdzuf0eD/9/nVIk.05Hm32	1	t	2026-04-24 10:44:04.806834+00	\N	2026-04-17 14:28:17.701141+00	4	\N	2026-04-17 16:00:52.521818+00	0	172.18.0.1
18	Reviewer	reviewer@actia.ged	$2b$10$GCAIQ81m.19UqmOBkkFUtOnL17ZswfMkVsXwkR.io/iVBe8TXz3CG	3	t	\N	\N	2026-04-21 15:53:40.799489+00	0	\N	\N	0	\N
20	Admin	admin@actia.ged	$2b$10$AngI7py/TfncQlwsjBhCwuec1LLSwAH.RmQWqV.IkdKGC0UlnGYKO	1	t	\N	\N	2026-04-24 10:45:40.300781+00	0	\N	\N	0	\N
21	Ing Qualité	ing@actia.ged	$2b$10$gelwdNQ84B4RLkrv.hw6uuMVWrYz620vXw4zuZka6.uoGSKaEC0wi	2	t	\N	\N	2026-04-24 10:45:40.369169+00	0	\N	\N	0	\N
2	Ing Qualité	ing@test.com	$2b$10$oxpUMRTziV2GdhzJ5on2qeOb.RltwGyx/Yr2YQxOeleV7NUPBLvZO	2	t	2026-04-24 13:12:21.295065+00	\N	2026-04-17 14:28:17.778075+00	3	\N	\N	0	172.18.0.1
\.


--
-- Data for Name: validations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.validations (id, document_id, validator_id, validator_name, validated_at, comment, decision, version_letter, signature_hash, is_locked, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.versions (id, document_id, version_letter, file_path, file_name, file_size, mime_type, change_summary, created_at, sharepoint_link) FROM stdin;
18	5	vA	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/GU_Guides/GU0002_Guide_vA.pdf	GU0002_Guide_vA.pdf	110471	application/pdf	tttt	2026-04-17 16:37:26.070885+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=CWnG7M
19	5	v-	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/GU_Guides/GU0002_Guide_vA.pdf	GU0002_Guide_vA.pdf	110471	application/pdf	Version initiale	2026-04-17 14:46:30.041727+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=CWnG7M
10	4	vA	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_de_Travail/GU_Guides/GU0001_Guide_vA.pdf	GU0001_Guide_vA.pdf	\N	application/pdf	Version initiale	2026-03-18 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
11	4	vA1	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_de_Travail/GU_Guides/GU0001_Guide_vA1.pdf	GU0001_Guide_vA1.pdf	\N	application/pdf	Révision A1	2026-03-28 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
12	7	vA	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/TR_Trames/TR0002_Trame_vA.pdf	TR0002_Trame_vA.pdf	\N	application/pdf	Version initiale	2026-02-16 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
13	7	vA1	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/TR_Trames/TR0002_Trame_vA1.pdf	TR0002_Trame_vA1.pdf	\N	application/pdf	Révision A1	2026-03-03 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
14	9	vA	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/IN_Instructions/IN0001_Instruction_vA.pdf	IN0001_Instruction_vA.pdf	\N	application/pdf	Version initiale	2026-01-17 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
15	9	vA1	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/IN_Instructions/IN0001_Instruction_vA1.pdf	IN0001_Instruction_vA1.pdf	\N	application/pdf	Révision A1	2026-02-16 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
16	9	vA2	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/IN_Instructions/IN0001_Instruction_vA2.pdf	IN0001_Instruction_vA2.pdf	\N	application/pdf	Révision A2	2026-03-18 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
17	11	v-	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/GU_Guides/GU0003_Guide_-.pdf	GU0003_Guide_-.pdf	110471	application/pdf	Version initiale	2026-04-17 16:36:34.52227+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
20	4	v-	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_de_Travail/GU_Guides/GU0001_Guide_vA.pdf	GU0001_Guide_vA.pdf	\N	application/pdf	Version initiale	2026-03-17 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
21	9	v-	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/IN_Instructions/IN0001_Instruction_vA.pdf	IN0001_Instruction_vA.pdf	\N	application/pdf	Version initiale	2026-01-16 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
22	7	v-	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/TR_Trames/TR0002_Trame_vA.pdf	TR0002_Trame_vA.pdf	\N	application/pdf	Version initiale	2026-02-15 15:41:33.130818+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
23	1	v-	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_de_Travail/PR_Procedures/PR0001_Procedure_-.pdf	PR0001_Procedure_-.pdf	0	application/pdf	Version initiale	2026-04-17 14:46:30.041727+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
24	2	v-	01_PROCESSUS_STRATEGIQUE/Concevoir_Developper_Produits/PM_Processus_Metiers/PM_Conception_Developpement_Logiciel/PR0002_Procedure_-.pdf	PR0002_Procedure_-.pdf	0	application/pdf	Version initiale	2026-04-17 14:46:30.041727+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
25	3	v-	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_de_Travail/PR_Procedures/PR0003_Procedure_-.pdf	PR0003_Procedure_-.pdf	0	application/pdf	Version initiale	2026-04-17 14:46:30.041727+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
26	6	v-	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/TR_Trames/TR0001_Trame_-.pdf	TR0001_Trame_-.pdf	0	application/pdf	Version initiale	2026-04-17 14:46:30.041727+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=9GIq70
27	12	v-	01_PROCESSUS_STRATEGIQUE/Concevoir_Developper_Produits/PM_Processus_Metiers/PM_Conception_Developpement_Logiciel/IN0002_Instruction_-.pdf	IN0002_Instruction_-.pdf	110471	application/pdf	Version initiale	2026-04-18 20:56:03.617186+00	\N
28	11	vA	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/GU_Guides/GU0003_Guide_vA.pdf	GU0003_Guide_vA.pdf	110471	application/pdf	test	2026-04-22 19:57:01.155068+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=mZxNTq
29	3	vA	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_Travail/PR_Procedures/PR0003_Procedure_vA.pdf	PR0003_Procedure_vA.pdf	110471	application/pdf	test v	2026-04-23 21:18:04.318168+00	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=VoeW6f
\.


--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_query_logs_id_seq', 7, true);


--
-- Name: document_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.document_types_id_seq', 10, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.documents_id_seq', 12, true);


--
-- Name: folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.folders_id_seq', 67, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logs_id_seq', 29, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 34, true);


--
-- Name: processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.processes_id_seq', 16, true);


--
-- Name: reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reset_tokens_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: security_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.security_incidents_id_seq', 1, false);


--
-- Name: status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_id_seq', 10, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 21, true);


--
-- Name: validations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.validations_id_seq', 1, false);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.versions_id_seq', 29, true);


--
-- Name: ai_query_logs ai_query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_pkey PRIMARY KEY (id);


--
-- Name: doc_code_sequences doc_code_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doc_code_sequences
    ADD CONSTRAINT doc_code_sequences_pkey PRIMARY KEY (type_code, process_code);


--
-- Name: document_types document_types_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_code_key UNIQUE (code);


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);


--
-- Name: documents documents_doc_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_doc_code_key UNIQUE (doc_code);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: processes processes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processes
    ADD CONSTRAINT processes_pkey PRIMARY KEY (id);


--
-- Name: reset_tokens reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reset_tokens
    ADD CONSTRAINT reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: reset_tokens reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reset_tokens
    ADD CONSTRAINT reset_tokens_token_key UNIQUE (token);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: security_incidents security_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_pkey PRIMARY KEY (id);


--
-- Name: status status_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_name_key UNIQUE (name);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (id);


--
-- Name: token_blacklist token_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist
    ADD CONSTRAINT token_blacklist_pkey PRIMARY KEY (jti);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: validations validations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_logs_created ON public.ai_query_logs USING btree (created_at DESC);


--
-- Name: idx_ai_logs_intent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_logs_intent ON public.ai_query_logs USING btree (intent);


--
-- Name: idx_ai_logs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_logs_user ON public.ai_query_logs USING btree (user_id);


--
-- Name: idx_incidents_detected_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_detected_at ON public.security_incidents USING btree (detected_at DESC);


--
-- Name: idx_incidents_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_severity ON public.security_incidents USING btree (severity);


--
-- Name: idx_incidents_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_status ON public.security_incidents USING btree (status);


--
-- Name: idx_logs_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logs_action ON public.logs USING btree (action);


--
-- Name: idx_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logs_created_at ON public.logs USING btree (created_at DESC);


--
-- Name: idx_logs_document_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logs_document_id ON public.logs USING btree (document_id);


--
-- Name: idx_logs_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logs_severity ON public.logs USING btree (severity);


--
-- Name: idx_notif_unread; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notif_unread ON public.notifications USING btree (user_id, is_read);


--
-- Name: idx_notif_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notif_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_reset_tokens_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reset_tokens_token ON public.reset_tokens USING btree (token);


--
-- Name: idx_token_blacklist_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_token_blacklist_expires ON public.token_blacklist USING btree (expires_at);


--
-- Name: idx_validations_decision; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_validations_decision ON public.validations USING btree (decision);


--
-- Name: idx_validations_document_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_validations_document_id ON public.validations USING btree (document_id);


--
-- Name: idx_validations_validator_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_validations_validator_id ON public.validations USING btree (validator_id);


--
-- Name: ai_query_logs ai_query_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- Name: documents documents_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: documents documents_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.document_types(id);


--
-- Name: folders folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.folders(id) ON DELETE CASCADE;


--
-- Name: logs logs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: logs logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reset_tokens reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reset_tokens
    ADD CONSTRAINT reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: security_incidents security_incidents_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: security_incidents security_incidents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: validations validations_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: validations validations_validator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_validator_id_fkey FOREIGN KEY (validator_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: versions versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4yc7S8OTKo3OCN134kaihDo0I0WVbM9u46pawHul2nx0sAk998fZzKme77cScsJ

