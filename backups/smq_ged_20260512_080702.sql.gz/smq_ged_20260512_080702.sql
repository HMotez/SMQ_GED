--
-- PostgreSQL database dump
--

\restrict 3fNsgiXngXub7esHvIxjvcA7AlAhHnLxPk5ndGoNM6pZkqoAmIgDueyvisDDwO8

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_query_logs; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.ai_query_logs (
    id integer NOT NULL,
    user_id integer,
    query_text text NOT NULL,
    intent character varying(80),
    result_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_query_logs OWNER TO smq_app;

--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.ai_query_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_query_logs_id_seq OWNER TO smq_app;

--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.ai_query_logs_id_seq OWNED BY public.ai_query_logs.id;


--
-- Name: doc_code_sequences; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.doc_code_sequences (
    type_code character varying(10) NOT NULL,
    process_code character varying(50) DEFAULT 'GLOBAL'::character varying NOT NULL,
    last_number integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.doc_code_sequences OWNER TO smq_app;

--
-- Name: document_types; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.document_types (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    label character varying(100) NOT NULL
);


ALTER TABLE public.document_types OWNER TO smq_app;

--
-- Name: document_types_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.document_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_types_id_seq OWNER TO smq_app;

--
-- Name: document_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.document_types_id_seq OWNED BY public.document_types.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    doc_code character varying(50),
    title character varying(255) NOT NULL,
    responsible character varying(255),
    next_review_date date,
    status_id integer NOT NULL,
    current_version character varying(10) DEFAULT '-'::character varying,
    folder_id integer,
    type_id integer,
    process_id integer,
    created_by integer,
    origin character varying(10) DEFAULT 'INTERNE'::character varying,
    context text,
    project_ref character varying(100),
    keywords text[],
    file_path character varying(500),
    file_name character varying(255),
    file_size bigint,
    mime_type character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    reviewer_emails text[] DEFAULT '{}'::text[],
    validator_emails text[] DEFAULT '{}'::text[],
    sharepoint_link text,
    validated_version character varying(10)
);


ALTER TABLE public.documents OWNER TO smq_app;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO smq_app;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: folders; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.folders (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    level integer DEFAULT 1 NOT NULL,
    parent_id integer
);


ALTER TABLE public.folders OWNER TO smq_app;

--
-- Name: folders_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.folders_id_seq OWNER TO smq_app;

--
-- Name: folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.folders_id_seq OWNED BY public.folders.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    document_id integer,
    action character varying(100) NOT NULL,
    user_id integer,
    details jsonb,
    created_at timestamp with time zone DEFAULT now(),
    ip_address character varying(64),
    user_agent text,
    severity character varying(16) DEFAULT 'info'::character varying NOT NULL,
    CONSTRAINT logs_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.logs OWNER TO smq_app;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.logs_id_seq OWNER TO smq_app;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    document_id integer,
    message text NOT NULL,
    type character varying(50) DEFAULT 'validation'::character varying NOT NULL,
    is_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO smq_app;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO smq_app;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: processes; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.processes (
    id integer NOT NULL,
    code character varying(50),
    strategic_process character varying(100),
    main_process character varying(100),
    sub_process character varying(100)
);


ALTER TABLE public.processes OWNER TO smq_app;

--
-- Name: processes_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.processes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.processes_id_seq OWNER TO smq_app;

--
-- Name: processes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.processes_id_seq OWNED BY public.processes.id;


--
-- Name: reset_tokens; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.reset_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token character varying(128) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.reset_tokens OWNER TO smq_app;

--
-- Name: reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reset_tokens_id_seq OWNER TO smq_app;

--
-- Name: reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.reset_tokens_id_seq OWNED BY public.reset_tokens.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(255)
);


ALTER TABLE public.roles OWNER TO smq_app;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO smq_app;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: security_incidents; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.security_incidents (
    id integer NOT NULL,
    type character varying(50) NOT NULL,
    severity character varying(16) DEFAULT 'warning'::character varying NOT NULL,
    description text NOT NULL,
    ip_address character varying(64),
    user_id integer,
    detected_at timestamp with time zone DEFAULT now(),
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    resolved_at timestamp with time zone,
    resolved_by integer,
    notes text,
    CONSTRAINT security_incidents_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT security_incidents_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying, 'resolved'::character varying])::text[])))
);


ALTER TABLE public.security_incidents OWNER TO smq_app;

--
-- Name: security_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.security_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.security_incidents_id_seq OWNER TO smq_app;

--
-- Name: security_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.security_incidents_id_seq OWNED BY public.security_incidents.id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.status (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.status OWNER TO smq_app;

--
-- Name: status_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.status_id_seq OWNER TO smq_app;

--
-- Name: status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.status_id_seq OWNED BY public.status.id;


--
-- Name: token_blacklist; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.token_blacklist (
    jti character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.token_blacklist OWNER TO smq_app;

--
-- Name: users; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    role_id integer,
    is_active boolean DEFAULT false,
    last_login timestamp with time zone,
    requested_role character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    last_login_ip character varying(64),
    login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone
);


ALTER TABLE public.users OWNER TO smq_app;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO smq_app;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: validations; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.validations (
    id integer NOT NULL,
    document_id integer NOT NULL,
    validator_id integer NOT NULL,
    validator_name character varying(255),
    validated_at timestamp with time zone DEFAULT now(),
    comment text,
    decision character varying(20) DEFAULT 'EN_ATTENTE'::character varying NOT NULL,
    version_letter character varying(5),
    signature_hash character varying(512),
    is_locked boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT validations_decision_check CHECK (((decision)::text = ANY ((ARRAY['APPROUVÉ'::character varying, 'REJETÉ'::character varying, 'EN_ATTENTE'::character varying])::text[])))
);


ALTER TABLE public.validations OWNER TO smq_app;

--
-- Name: validations_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.validations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.validations_id_seq OWNER TO smq_app;

--
-- Name: validations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.validations_id_seq OWNED BY public.validations.id;


--
-- Name: versions; Type: TABLE; Schema: public; Owner: smq_app
--

CREATE TABLE public.versions (
    id integer NOT NULL,
    document_id integer NOT NULL,
    version_letter character varying(10) NOT NULL,
    file_path character varying(500),
    file_name character varying(255),
    file_size bigint,
    mime_type character varying(100),
    change_summary text,
    created_at timestamp with time zone DEFAULT now(),
    created_by integer,
    sharepoint_link text
);


ALTER TABLE public.versions OWNER TO smq_app;

--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: smq_app
--

CREATE SEQUENCE public.versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.versions_id_seq OWNER TO smq_app;

--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: smq_app
--

ALTER SEQUENCE public.versions_id_seq OWNED BY public.versions.id;


--
-- Name: ai_query_logs id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.ai_query_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_query_logs_id_seq'::regclass);


--
-- Name: document_types id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.document_types ALTER COLUMN id SET DEFAULT nextval('public.document_types_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: folders id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.folders ALTER COLUMN id SET DEFAULT nextval('public.folders_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: processes id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.processes ALTER COLUMN id SET DEFAULT nextval('public.processes_id_seq'::regclass);


--
-- Name: reset_tokens id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.reset_tokens_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: security_incidents id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.security_incidents ALTER COLUMN id SET DEFAULT nextval('public.security_incidents_id_seq'::regclass);


--
-- Name: status id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.status ALTER COLUMN id SET DEFAULT nextval('public.status_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: validations id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.validations ALTER COLUMN id SET DEFAULT nextval('public.validations_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.versions ALTER COLUMN id SET DEFAULT nextval('public.versions_id_seq'::regclass);


--
-- Data for Name: ai_query_logs; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.ai_query_logs (id, user_id, query_text, intent, result_count, created_at) FROM stdin;
1	2	Quels documents ont dépassé leur date de révision ?	expired_docs	2	2026-05-01 21:10:52.245837+00
2	2	Quels documents sont en cours de rédaction ?	draft_docs	3	2026-05-01 21:11:30.6049+00
3	2	Puis-je consulter le contenu de ces documents ?	activity_logs	0	2026-05-01 21:11:35.058568+00
4	2	Quels documents sont en retard de révision ?	overdue_docs	2	2026-05-02 09:59:42.896807+00
5	2	Quels documents ont une révision dans les 30 prochains jours ?	upcoming_reviews	1	2026-05-02 09:59:45.680994+00
6	2	bonjour	help	0	2026-05-02 09:59:52.99315+00
7	2	c'est quoi iso 9001	general_advice	0	2026-05-02 10:00:06.052145+00
8	2	donner moi le totale du doc	statistics	0	2026-05-02 10:00:27.77291+00
9	2	Donne-moi la liste de tous les documents	list_all	5	2026-05-02 10:01:38.663343+00
10	2	Quels documents sont en attente de validation ?	validation_pending	1	2026-05-03 09:45:51.883559+00
11	2	Quels documents sont en retard de révision ?	overdue_docs	2	2026-05-03 09:45:55.777359+00
12	2	Liste les documents obsolètes	obsolete_docs	0	2026-05-03 09:45:58.696632+00
13	1	Quels documents ont une révision dans les 30 prochains jours ?	upcoming_reviews	2	2026-05-03 15:09:14.409763+00
14	1	Quels sont mes documents ?	my_docs	2	2026-05-03 15:09:17.972089+00
15	1	Quels documents n'ont jamais été consultés ?	activity_logs	0	2026-05-03 16:43:50.803694+00
16	1	Quels documents sont actuellement diffusés ?	published_docs	0	2026-05-03 17:22:45.176353+00
17	1	Quelles sont les dates de révision des documents ?	dates_overview	0	2026-05-03 17:22:50.453515+00
18	1	Quels documents sont en cours de relecture ?	in_relecture	0	2026-05-03 17:22:57.361078+00
19	1	Comment fonctionne la procédure de validation ISO ?	how_to_validate	0	2026-05-03 17:23:01.742193+00
20	2	Quels documents ont dépassé leur date de révision ?	expired_docs	1	2026-05-04 08:14:27.274563+00
21	2	Quels sont mes documents ?	my_docs	5	2026-05-04 08:14:42.347013+00
22	1	c'est iso 9001	general_advice	0	2026-05-06 10:35:12.168561+00
23	2	Quels documents sont actuellement diffusés ?	published_docs	0	2026-05-07 21:41:45.312465+00
\.


--
-- Data for Name: doc_code_sequences; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.doc_code_sequences (type_code, process_code, last_number) FROM stdin;
PR	GLOBAL	2
GU	GLOBAL	3
MN	GLOBAL	1
TR	GLOBAL	5
\.


--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.document_types (id, code, label) FROM stdin;
1	PR	Procédures
2	IN	Instructions
3	GU	Guides
4	MN	Manuel
5	TR	Trames
6	EN	Enregistrements
7	FM	Fiches Missions
8	FF	Fiches Fonctions
9	PT	Plan de traitement
10	EX	Externe
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.documents (id, doc_code, title, responsible, next_review_date, status_id, current_version, folder_id, type_id, process_id, created_by, origin, context, project_ref, keywords, file_path, file_name, file_size, mime_type, created_at, updated_at, reviewer_emails, validator_emails, sharepoint_link, validated_version) FROM stdin;
6	GU0001_Guide_-	Guide	Moetez	2026-06-05	14	-	405	3	405	2	INTERNE	PROCESSUS	\N	{gu}	02_PROCESSUS_SUPPORT/Manager_Sante_Securite_Travail/GU_Guides/GU0001_Guide_-.pdf	GU0001_Guide_-.pdf	110471	application/pdf	2026-05-01 21:09:16.440759+00	2026-05-01 21:09:16.440759+00	{motezhm40@gmail.com}	\N	\N	\N
9	TR0004_Trame_A	Trame	Moetez	2026-05-28	3	A	413	5	413	1	INTERNE	SYSTEME_QUALITE	\N	{tr}	02_PROCESSUS_SUPPORT/Manager_Motiver_Ressources/TR_Trames/TR0004_Trame_A.pdf	TR0004_Trame_A.pdf	110471	application/pdf	2026-05-06 09:47:03.511795+00	2026-05-06 09:47:03.511795+00	{motezhm40@gmail.com}	\N	\N	\N
10	GU0003_Guide_A	Guide	Moetez	2026-05-20	1	A	415	3	415	2	EXTERNE	PROCESSUS	\N	{gu}	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/GU_Guides/GU0003_Guide_A.pdf	GU0003_Guide_A.pdf	110471	application/pdf	2026-05-06 14:19:05.111441+00	2026-05-06 14:19:05.111441+00	{motezhm40@gmail.com,reviewer@test.com}	\N	\N	\N
3	PR0001_Procedure_-	Procédure	Moetez	2026-05-28	9	-	407	1	407	1	INTERNE	SYSTEME_QUALITE	\N	{pr}	02_PROCESSUS_SUPPORT/Manager_Sante_Securite_Travail/PR_Procedures/PR0001_Procedure_-.pdf	PR0001_Procedure_-.pdf	110471	application/pdf	2026-05-01 18:36:27.19572+00	2026-05-01 18:36:27.19572+00	{rev@test.com}	\N	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=yb3CNw	-
8	GU0002_Guide_A	Guide	Alison	2026-06-04	4	A	395	3	395	2	EXTERNE	PROCESSUS	\N	{gu}	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_Travail/GU_Guides/GU0002_Guide_A.pdf	GU0002_Guide_A.pdf	110471	application/pdf	2026-05-03 09:56:59.916292+00	2026-05-03 09:56:59.916292+00	{motezhm40@gmail.com}	\N	\N	\N
2	TR0001_Trame_A1	Trame	Moetez	2026-06-26	8	A1	8	5	8	2	INTERNE	SYSTEME_QUALITE	\N	{tr}	02_PROCESSUS_SUPPORT/Manager_Sante_Securite_Travail/TR0001_Trame_A1.pdf	TR0001_Trame_A1.pdf	110471	application/pdf	2026-05-01 17:26:19.892033+00	2026-05-01 17:26:19.892033+00	{rev@test.com}	\N	\N	\N
4	TR0002_Trame_-	Trame	Moetez	2026-03-25	8	-	393	5	393	2	INTERNE	PROCESSUS	\N	{tr}	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/TR_Trames/TR0002_Trame_-.pdf	TR0002_Trame_-.pdf	110471	application/pdf	2026-05-01 21:00:59.373113+00	2026-05-01 21:00:59.373113+00	{reviewer@test.com}	\N	\N	-
5	PR0002_Procedure_-	Procédure	moetez	2026-04-22	14	-	402	1	402	1	EXTERNE	PROJET	\N	{pr}	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/PR_Procedures/PR0002_Procedure_-.pdf	PR0002_Procedure_-.pdf	110471	application/pdf	2026-05-01 21:05:15.828924+00	2026-05-01 21:05:15.828924+00	{motezhm40@gmail.com}	\N	\N	\N
7	TR0003_Trame_A2	Trame	Moetez	2026-05-28	4	A2	393	5	393	2	INTERNE	SUPPORT	\N	{tr}	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/TR_Trames/TR0003_Trame_A2.pdf	TR0003_Trame_A2.pdf	110471	application/pdf	2026-05-02 10:29:31.701291+00	2026-05-02 10:29:31.701291+00	{motezhm40@gmail.com}	\N	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=p0Qkuc	\N
11	MN0001_Manuel_A	Manuel	Alison	2026-04-17	1	A	459	4	459	2	EXTERNE	SUPPORT	\N	{mn}	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/MA_Manuel/MN0001_Manuel_A.pdf	MN0001_Manuel_A.pdf	110471	application/pdf	2026-05-08 14:32:00.035322+00	2026-05-08 14:32:00.035322+00	{motezhm40@gmail.com}	\N	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=5Zymj6	\N
12	TR0005_Trame_-	Trame	Moetez	2026-05-30	1	-	418	5	418	2	INTERNE	SUPPORT	\N	{tr}	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/TR_Trames/TR0005_Trame_-.pdf	TR0005_Trame_-.pdf	110471	application/pdf	2026-05-08 15:09:16.017493+00	2026-05-08 15:09:16.017493+00	{motezhm40@gmail.com,reviewer@test.com}	\N	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=ENuUZw	\N
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.folders (id, name, code, level, parent_id) FROM stdin;
1	01_PROCESSUS_STRATEGIQUE	01-PS	1	\N
2	02_PROCESSUS_SUPPORT	02-SP	1	\N
3	Concevoir_Developper_Produits	CDP	2	1
4	Faire_Evoluer_Securiser_SI	FESI	2	1
5	Fournir_Prestations_Service	FPS	2	1
6	Gerer_Infrastructure_Environnement_Travail	GIET	2	1
7	Maitriser_Achats_Logistique	MAL	2	2
8	Manager_Sante_Securite_Travail	MSST	2	2
9	Manager_Motiver_Ressources	MMR	2	2
10	Piloter_l_Entreprise	PE	2	2
11	PS_Processus_Strategique	CDP-PS	3	3
384	EN_Enregistrements	FESI-EN	3	4
385	GU_Guides	FESI-GU	3	4
386	IN_Instructions	FESI-IN	3	4
387	PR_Procedures	FESI-PR	3	4
388	TR_Trames	FESI-TR	3	4
389	EN_Enregistrements	FPS-EN	3	5
390	GU_Guides	FPS-GU	3	5
391	IN_Instructions	FPS-IN	3	5
392	PR_Procedures	FPS-PR	3	5
393	TR_Trames	FPS-TR	3	5
394	EN_Enregistrements	GIET-EN	3	6
395	GU_Guides	GIET-GU	3	6
396	IN_Instructions	GIET-IN	3	6
397	PR_Procedures	GIET-PR	3	6
398	TR_Trames	GIET-TR	3	6
399	EN_Enregistrements	MAL-EN	3	7
400	GU_Guides	MAL-GU	3	7
401	IN_Instructions	MAL-IN	3	7
402	PR_Procedures	MAL-PR	3	7
403	TR_Trames	MAL-TR	3	7
404	EN_Enregistrements	MSST-EN	3	8
405	GU_Guides	MSST-GU	3	8
406	IN_Instructions	MSST-IN	3	8
407	PR_Procedures	MSST-PR	3	8
408	TR_Trames	MSST-TR	3	8
409	EN_Enregistrements	MMR-EN	3	9
410	GU_Guides	MMR-GU	3	9
411	IN_Instructions	MMR-IN	3	9
412	PR_Procedures	MMR-PR	3	9
413	TR_Trames	MMR-TR	3	9
414	EN_Enregistrements	PE-EN	3	10
415	GU_Guides	PE-GU	3	10
416	IN_Instructions	PE-IN	3	10
417	PR_Procedures	PE-PR	3	10
418	TR_Trames	PE-TR	3	10
419	EN_Enregistrements	CDP-PS-EN	4	11
420	GU_Guides	CDP-PS-GU	4	11
421	IN_Instructions	CDP-PS-IN	4	11
422	PR_Procedures	CDP-PS-PR	4	11
423	TR_Trames	CDP-PS-TR	4	11
459	MA_Manuel	FPS-MA	3	5
460	FF_Fiches_Fonctions	MMR-FF	3	9
461	FM_Fiches_Missions	MMR-FM	3	9
462	FF_Fiches_Fonctions	PE-FF	3	10
463	FM_Fiches_Missions	PE-FM	3	10
12	PM_Conception_Mecanique	CDP-MC	4	464
13	PM_Conception_Developpement_Logiciel	CDP-DL	4	464
14	PM_Conception_Developpement_Outillages	CDP-DO	4	464
15	PM_Electronique	CDP-EL	4	464
16	PM_Qualification_Thermomecanique	CDP-QT	4	464
17	PM_Validation	CDP-VA	4	464
18	PM_Industrialisation_Vie_Serie	CDP-IVS	4	464
424	EN_Enregistrements	CDP-MC-EN	5	12
425	GU_Guides	CDP-MC-GU	5	12
426	IN_Instructions	CDP-MC-IN	5	12
427	PR_Procedures	CDP-MC-PR	5	12
428	TR_Trames	CDP-MC-TR	5	12
429	EN_Enregistrements	CDP-DL-EN	5	13
430	GU_Guides	CDP-DL-GU	5	13
431	IN_Instructions	CDP-DL-IN	5	13
432	PR_Procedures	CDP-DL-PR	5	13
433	TR_Trames	CDP-DL-TR	5	13
434	EN_Enregistrements	CDP-DO-EN	5	14
435	GU_Guides	CDP-DO-GU	5	14
436	IN_Instructions	CDP-DO-IN	5	14
437	PR_Procedures	CDP-DO-PR	5	14
438	TR_Trames	CDP-DO-TR	5	14
439	EN_Enregistrements	CDP-EL-EN	5	15
440	GU_Guides	CDP-EL-GU	5	15
441	IN_Instructions	CDP-EL-IN	5	15
442	PR_Procedures	CDP-EL-PR	5	15
443	TR_Trames	CDP-EL-TR	5	15
464	PM_Processus_Metiers	01-CDP-PM	3	3
444	EN_Enregistrements	CDP-QT-EN	5	16
445	GU_Guides	CDP-QT-GU	5	16
446	IN_Instructions	CDP-QT-IN	5	16
447	PR_Procedures	CDP-QT-PR	5	16
448	TR_Trames	CDP-QT-TR	5	16
449	EN_Enregistrements	CDP-VA-EN	5	17
450	GU_Guides	CDP-VA-GU	5	17
451	IN_Instructions	CDP-VA-IN	5	17
452	PR_Procedures	CDP-VA-PR	5	17
453	TR_Trames	CDP-VA-TR	5	17
454	EN_Enregistrements	CDP-IVS-EN	5	18
455	GU_Guides	CDP-IVS-GU	5	18
456	IN_Instructions	CDP-IVS-IN	5	18
457	PR_Procedures	CDP-IVS-PR	5	18
458	TR_Trames	CDP-IVS-TR	5	18
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.logs (id, document_id, action, user_id, details, created_at, ip_address, user_agent, severity) FROM stdin;
10	2	CREATE_DOCUMENT	2	{"origin": "INTERNE", "doc_code": "TR0001_Trame_-", "typeCode": "TR", "folderCode": "MSST"}	2026-05-01 17:26:19.892033+00	\N	\N	info
11	2	STATUS_CHANGE	\N	{"to": "En rédaction", "from": "Brouillon", "doc_code": "TR0001_Trame_-", "timestamp": "2026-05-01T17:27:41.526Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 17:27:41.522987+00	\N	\N	info
12	2	NEW_VERSION	2	{"to": "A", "from": "-", "change_summary": "test"}	2026-05-01 17:28:10.21874+00	\N	\N	info
13	2	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En rédaction", "doc_code": "TR0001_Trame_A", "timestamp": "2026-05-01T17:34:30.921Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 17:34:30.912968+00	\N	\N	info
14	2	STATUS_CHANGE	\N	{"to": "En relecture", "from": "Appel en relecture", "doc_code": "TR0001_Trame_A", "timestamp": "2026-05-01T17:34:31.859Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 17:34:31.85289+00	\N	\N	info
15	2	STATUS_CHANGE	\N	{"to": "En validation", "from": "En relecture", "doc_code": "TR0001_Trame_A", "timestamp": "2026-05-01T17:34:40.388Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 17:34:40.381201+00	\N	\N	info
16	2	VERSION_SUPERSEDED	2	{"reason": "Remplacée par une nouvelle version", "doc_code": "TR0001_Trame_A", "new_version": "A1", "superseded_version": "A"}	2026-05-01 17:35:09.862233+00	\N	\N	info
17	2	NEW_VERSION	2	{"to": "A1", "from": "A", "change_summary": "ttttt"}	2026-05-01 17:35:09.862233+00	\N	\N	info
19	3	CREATE_DOCUMENT	1	{"origin": "INTERNE", "doc_code": "PR0001_Procedure_-", "typeCode": "PR", "folderCode": "MSST-PR"}	2026-05-01 18:36:27.19572+00	\N	\N	info
25	2	VALIDATION_CREATED	1	{"comment": "correct", "version": "A1", "decision": "APPROUVÉ", "doc_code": "TR0001_Trame_A1", "validator_id": 1, "validation_id": 1, "signature_hash": "988d452a6543fed54f6da83f143150f6c50c4706989a6ea82a11de072f48ee5b", "validator_name": "Admin"}	2026-05-01 18:43:10.973275+00	\N	\N	info
26	2	STATUS_CHANGE	1	{"to": "Validé", "from": "En validation", "trigger": "auto_approval"}	2026-05-01 18:43:10.973275+00	\N	\N	info
34	4	CREATE_DOCUMENT	2	{"origin": "INTERNE", "doc_code": "TR0002_Trame_-", "typeCode": "TR", "folderCode": "FPS-TR"}	2026-05-01 21:00:59.373113+00	\N	\N	info
37	5	CREATE_DOCUMENT	1	{"origin": "EXTERNE", "doc_code": "PR0002_Procedure_-", "typeCode": "PR", "folderCode": "MAL-PR"}	2026-05-01 21:05:15.828924+00	\N	\N	info
40	6	CREATE_DOCUMENT	2	{"origin": "INTERNE", "doc_code": "GU0001_Guide_-", "typeCode": "GU", "folderCode": "MSST-GU"}	2026-05-01 21:09:16.440759+00	\N	\N	info
41	3	STATUS_CHANGE	\N	{"to": "En rédaction", "from": "Brouillon", "doc_code": "PR0001_Procedure_-", "timestamp": "2026-05-01T21:09:23.381Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:09:23.375867+00	\N	\N	info
42	3	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En rédaction", "doc_code": "PR0001_Procedure_-", "timestamp": "2026-05-01T21:09:24.129Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:09:24.121503+00	\N	\N	info
43	3	STATUS_CHANGE	\N	{"to": "En relecture", "from": "Appel en relecture", "doc_code": "PR0001_Procedure_-", "timestamp": "2026-05-01T21:09:24.655Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:09:24.640874+00	\N	\N	info
44	3	STATUS_CHANGE	\N	{"to": "En validation", "from": "En relecture", "doc_code": "PR0001_Procedure_-", "timestamp": "2026-05-01T21:10:02.131Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:10:02.125138+00	\N	\N	info
45	2	STATUS_CHANGE	\N	{"to": "Approuvé", "from": "Validé", "doc_code": "TR0001_Trame_A1", "timestamp": "2026-05-01T21:10:17.208Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:10:17.20159+00	\N	\N	info
46	2	STATUS_CHANGE	\N	{"to": "Diffusé", "from": "Approuvé", "doc_code": "TR0001_Trame_A1", "timestamp": "2026-05-01T21:10:17.975Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:10:17.96532+00	\N	\N	info
47	2	STATUS_CHANGE	\N	{"to": "Obsolète", "from": "Diffusé", "doc_code": "TR0001_Trame_A1", "timestamp": "2026-05-01T21:10:18.199Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:10:18.194667+00	\N	\N	info
48	2	STATUS_CHANGE	\N	{"to": "Archivé", "from": "Obsolète", "doc_code": "TR0001_Trame_A1", "timestamp": "2026-05-01T21:10:18.385Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:10:18.377612+00	\N	\N	info
49	6	STATUS_CHANGE	\N	{"to": "En rédaction", "from": "Brouillon", "doc_code": "GU0001_Guide_-", "timestamp": "2026-05-01T21:12:33.943Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:12:33.937982+00	\N	\N	info
50	6	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En rédaction", "doc_code": "GU0001_Guide_-", "timestamp": "2026-05-01T21:12:34.653Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:12:34.648888+00	\N	\N	info
51	4	STATUS_CHANGE	\N	{"to": "En rédaction", "from": "Brouillon", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-01T21:12:38.830Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:12:38.824485+00	\N	\N	info
52	4	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En rédaction", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-01T21:12:38.985Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:12:38.980568+00	\N	\N	info
53	4	STATUS_CHANGE	\N	{"to": "En relecture", "from": "Appel en relecture", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-01T21:12:40.033Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:12:40.029919+00	\N	\N	info
54	4	STATUS_CHANGE	\N	{"to": "En correction", "from": "En relecture", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-01T21:12:40.926Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-01 21:12:40.92142+00	\N	\N	info
85	7	CREATE_DOCUMENT	2	{"origin": "INTERNE", "doc_code": "TR0003_Trame_-", "typeCode": "TR", "folderCode": "FPS-TR"}	2026-05-02 10:29:31.701291+00	\N	\N	info
87	8	CREATE_DOCUMENT	2	{"origin": "EXTERNE", "doc_code": "GU0002_Guide_-", "typeCode": "GU", "folderCode": "GIET-GU"}	2026-05-03 09:56:59.916292+00	\N	\N	info
88	4	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En correction", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-03T09:57:09.872Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 09:57:09.860057+00	\N	\N	info
89	4	STATUS_CHANGE	\N	{"to": "En relecture", "from": "Appel en relecture", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-03T09:57:11.474Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 09:57:11.469357+00	\N	\N	info
90	4	STATUS_CHANGE	\N	{"to": "En validation", "from": "En relecture", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-03T09:57:14.825Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 09:57:14.817805+00	\N	\N	info
91	7	STATUS_CHANGE	\N	{"to": "En rédaction", "from": "Brouillon", "doc_code": "TR0003_Trame_-", "timestamp": "2026-05-03T09:57:31.602Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 09:57:31.596712+00	\N	\N	info
182	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:20:57.987934+00	::ffff:172.18.0.1	axios/1.16.0	info
92	7	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En rédaction", "doc_code": "TR0003_Trame_-", "timestamp": "2026-05-03T09:57:31.753Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 09:57:31.746136+00	\N	\N	info
93	7	STATUS_CHANGE	\N	{"to": "En relecture", "from": "Appel en relecture", "doc_code": "TR0003_Trame_-", "timestamp": "2026-05-03T09:57:31.895Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 09:57:31.892452+00	\N	\N	info
94	7	STATUS_CHANGE	\N	{"to": "En correction", "from": "En relecture", "doc_code": "TR0003_Trame_-", "timestamp": "2026-05-03T09:57:32.054Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 09:57:32.052895+00	\N	\N	info
95	7	NEW_VERSION	2	{"to": "A", "from": "-", "change_summary": "ttesstt"}	2026-05-03 09:58:02.250825+00	\N	\N	info
96	8	NEW_VERSION	2	{"to": "A", "from": "-", "change_summary": "tt"}	2026-05-03 10:07:47.188957+00	\N	\N	info
99	8	STATUS_CHANGE	\N	{"to": "En rédaction", "from": "Brouillon", "doc_code": "GU0002_Guide_A", "timestamp": "2026-05-03T10:29:45.210Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 10:29:45.205215+00	\N	\N	info
100	8	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En rédaction", "doc_code": "GU0002_Guide_A", "timestamp": "2026-05-03T10:29:48.934Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 10:29:48.927425+00	\N	\N	info
103	3	VALIDATION_CREATED	3	{"comment": "", "version": "-", "decision": "APPROUVÉ", "doc_code": "PR0001_Procedure_-", "validator_id": 3, "validation_id": 2, "signature_hash": "311fc33c14da1b24a43fa40a027bb154ca2739bb5e98a1e66c9b34b384da629c", "validator_name": "Reviewer"}	2026-05-03 10:57:18.043327+00	\N	\N	info
104	4	VALIDATION_CREATED	3	{"comment": "", "version": "-", "decision": "APPROUVÉ", "doc_code": "TR0002_Trame_-", "validator_id": 3, "validation_id": 3, "signature_hash": "8f98127ac05554272a004e2aa4fd26bf06fd0bf3b3eeed0a348dd699b7960d39", "validator_name": "Reviewer"}	2026-05-03 10:57:31.45137+00	\N	\N	info
106	4	STATUS_CHANGE	\N	{"to": "Validé", "from": "En validation", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-03T10:57:57.429Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 10:57:57.41787+00	\N	\N	info
107	4	STATUS_CHANGE	\N	{"to": "Approuvé", "from": "Validé", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-03T10:57:58.695Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 10:57:58.691919+00	\N	\N	info
108	4	STATUS_CHANGE	\N	{"to": "Diffusé", "from": "Approuvé", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-03T10:57:59.317Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 10:57:59.313487+00	\N	\N	info
109	4	STATUS_CHANGE	\N	{"to": "Obsolète", "from": "Diffusé", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-03T10:57:59.674Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 10:57:59.669249+00	\N	\N	info
110	4	STATUS_CHANGE	\N	{"to": "Archivé", "from": "Obsolète", "doc_code": "TR0002_Trame_-", "timestamp": "2026-05-03T10:58:00.480Z", "user_role": "Ing. Qualité", "ISO_transition": true}	2026-05-03 10:58:00.474698+00	\N	\N	info
113	3	STATUS_CHANGE	\N	{"to": "Validé", "from": "En validation", "doc_code": "PR0001_Procedure_-", "timestamp": "2026-05-03T11:56:15.893Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 11:56:15.880396+00	\N	\N	info
115	5	STATUS_CHANGE	\N	{"to": "En rédaction", "from": "Brouillon", "doc_code": "PR0002_Procedure_-", "timestamp": "2026-05-03T14:52:50.577Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 14:52:50.569374+00	\N	\N	info
116	5	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En rédaction", "doc_code": "PR0002_Procedure_-", "timestamp": "2026-05-03T14:53:00.497Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 14:53:00.49049+00	\N	\N	info
117	7	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En correction", "doc_code": "TR0003_Trame_A", "timestamp": "2026-05-03T14:59:59.074Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 14:59:59.06207+00	\N	\N	info
118	7	STATUS_CHANGE	\N	{"to": "En relecture", "from": "Appel en relecture", "doc_code": "TR0003_Trame_A", "timestamp": "2026-05-03T15:02:43.422Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 15:02:43.41381+00	\N	\N	info
119	7	STATUS_CHANGE	\N	{"to": "En correction", "from": "En relecture", "doc_code": "TR0003_Trame_A", "timestamp": "2026-05-03T15:02:48.514Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 15:02:48.506044+00	\N	\N	info
120	7	STATUS_CHANGE	\N	{"to": "En relecture", "from": "En correction", "doc_code": "TR0003_Trame_A", "timestamp": "2026-05-03T15:02:50.894Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 15:02:50.88584+00	\N	\N	info
121	7	STATUS_CHANGE	\N	{"to": "Appel en relecture", "from": "En relecture", "doc_code": "TR0003_Trame_A", "timestamp": "2026-05-03T15:02:55.039Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 15:02:55.033729+00	\N	\N	info
124	7	STATUS_CHANGE	\N	{"to": "En relecture", "from": "Appel en relecture", "doc_code": "TR0003_Trame_A", "timestamp": "2026-05-03T16:30:02.944Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 16:30:02.927106+00	\N	\N	info
125	7	STATUS_CHANGE	\N	{"to": "En validation", "from": "En relecture", "doc_code": "TR0003_Trame_A", "timestamp": "2026-05-03T16:30:05.392Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 16:30:05.384153+00	\N	\N	info
126	8	STATUS_CHANGE	\N	{"to": "En relecture", "from": "Appel en relecture", "doc_code": "GU0002_Guide_A", "timestamp": "2026-05-03T17:15:38.290Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 17:15:38.281685+00	\N	\N	info
127	8	STATUS_CHANGE	\N	{"to": "En validation", "from": "En relecture", "doc_code": "GU0002_Guide_A", "timestamp": "2026-05-03T17:15:41.151Z", "user_role": "Admin", "ISO_transition": true}	2026-05-03 17:15:41.143941+00	\N	\N	info
132	7	VERSION_SUPERSEDED	2	{"reason": "Remplacée par une nouvelle version", "doc_code": "TR0003_Trame_A", "new_version": "A1", "superseded_version": "A"}	2026-05-04 08:12:28.099569+00	\N	\N	info
133	7	NEW_VERSION	2	{"to": "A1", "from": "A", "change_summary": "test"}	2026-05-04 08:12:28.099569+00	\N	\N	info
134	\N	LOGIN_FAILURE	\N	{"email": "reviewer@tes.com", "reason": "user_not_found"}	2026-05-08 14:22:52.096298+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	warning
135	\N	LOGIN_NEW_IP	3	{"email": "reviewer@test.com", "current_ip": "172.18.0.1", "previous_ip": "::ffff:172.18.0.1"}	2026-05-08 14:23:01.651773+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	warning
136	\N	LOGIN_SUCCESS	3	{"ip": "172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-08 14:23:01.686032+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
137	\N	ACCESS_DENIED_403	3	{"path": "/api/users", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-08 14:29:49.591164+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	warning
138	\N	LOGIN_SUCCESS	2	{"ip": "172.18.0.1", "role": "Ing. Qualité", "email": "ing@test.com"}	2026-05-08 14:30:07.188697+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
139	11	CREATE_DOCUMENT	2	{"origin": "EXTERNE", "doc_code": "MN0001_Manuel_-", "typeCode": "MN", "folderCode": "FPS-MA"}	2026-05-08 14:32:00.035322+00	\N	\N	info
140	11	NEW_VERSION	2	{"to": "A", "from": "-", "change_summary": "vvvvv"}	2026-05-08 14:50:40.842712+00	\N	\N	info
141	12	CREATE_DOCUMENT	2	{"origin": "INTERNE", "doc_code": "TR0005_Trame_-", "typeCode": "TR", "folderCode": "PE-TR"}	2026-05-08 15:09:16.017493+00	\N	\N	info
142	\N	LOGIN_SUCCESS	1	{"ip": "172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:01:36.278542+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
143	\N	LOGIN_SUCCESS	2	{"ip": "172.18.0.1", "role": "Ing. Qualité", "email": "ing@test.com"}	2026-05-10 12:12:15.585834+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
144	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:14:14.577801+00	::ffff:172.18.0.1	axios/1.16.0	warning
145	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 2}	2026-05-10 12:14:14.674591+00	::ffff:172.18.0.1	axios/1.16.0	warning
146	\N	ACCOUNT_LOCKED	3	{"email": "reviewer@test.com", "attempts": 3, "locked_until": "2026-05-10T12:29:14.763Z"}	2026-05-10 12:14:14.771466+00	::ffff:172.18.0.1	axios/1.16.0	critical
147	\N	LOGIN_FAILURE	\N	{"email": "email_qui_nexiste_pas_xyz999@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:14:34.987198+00	::ffff:172.18.0.1	axios/1.16.0	warning
148	\N	LOGIN_FAILURE	1	{"email": "admin@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:14:35.0685+00	::ffff:172.18.0.1	axios/1.16.0	warning
149	\N	LOGIN_FAILURE	\N	{"email": "email_inconnu_abc123@test.invalid", "reason": "user_not_found"}	2026-05-10 12:14:35.140561+00	::ffff:172.18.0.1	axios/1.16.0	warning
150	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:14:35.219911+00	::ffff:172.18.0.1	axios/1.16.0	warning
151	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:14:35.295148+00	::ffff:172.18.0.1	axios/1.16.0	warning
152	\N	LOGIN_NEW_IP	1	{"email": "admin@test.com", "current_ip": "::ffff:172.18.0.1", "previous_ip": "172.18.0.1"}	2026-05-10 12:14:56.41018+00	::ffff:172.18.0.1	axios/1.16.0	warning
153	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:14:56.429735+00	::ffff:172.18.0.1	axios/1.16.0	info
154	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:14:56.54105+00	::ffff:172.18.0.1	axios/1.16.0	info
155	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:14:56.568279+00	::ffff:172.18.0.1	axios/1.16.0	warning
156	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:14:56.656178+00	::ffff:172.18.0.1	axios/1.16.0	info
157	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:15:26.474791+00	::ffff:172.18.0.1	axios/1.16.0	warning
158	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:15:26.561929+00	::ffff:172.18.0.1	axios/1.16.0	info
159	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:15:26.568375+00	::ffff:172.18.0.1	axios/1.16.0	warning
160	\N	ACCESS_DENIED_401	\N	{"path": "/api/users", "method": "GET"}	2026-05-10 12:15:31.071213+00	::ffff:172.18.0.1	axios/1.16.0	warning
161	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:15:31.081449+00	::ffff:172.18.0.1	axios/1.16.0	warning
162	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:15:31.096639+00	::ffff:172.18.0.1	axios/1.16.0	warning
163	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:15:31.1061+00	::ffff:172.18.0.1	axios/1.16.0	warning
164	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:15:31.112717+00	::ffff:172.18.0.1	axios/1.16.0	warning
165	\N	LOGIN_FAILURE	\N	{"email": "'; DROP TABLE users;--", "reason": "user_not_found"}	2026-05-10 12:15:38.420235+00	::ffff:172.18.0.1	axios/1.16.0	warning
166	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:15:50.337206+00	::ffff:172.18.0.1	axios/1.16.0	info
167	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:15:50.465926+00	::ffff:172.18.0.1	axios/1.16.0	warning
168	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:15:50.584766+00	::ffff:172.18.0.1	axios/1.16.0	info
169	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:15:50.610837+00	::ffff:172.18.0.1	axios/1.16.0	warning
170	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:18:49.971927+00	::ffff:172.18.0.1	axios/1.16.0	info
171	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:18:50.082991+00	::ffff:172.18.0.1	axios/1.16.0	warning
172	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:18:50.175771+00	::ffff:172.18.0.1	axios/1.16.0	info
173	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:18:50.202769+00	::ffff:172.18.0.1	axios/1.16.0	warning
174	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:20:13.315869+00	::ffff:172.18.0.1	axios/1.16.0	info
175	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:20:13.441183+00	::ffff:172.18.0.1	axios/1.16.0	warning
176	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:20:13.549168+00	::ffff:172.18.0.1	axios/1.16.0	info
177	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:20:13.57717+00	::ffff:172.18.0.1	axios/1.16.0	warning
178	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:20:57.653949+00	::ffff:172.18.0.1	axios/1.16.0	info
179	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:20:57.760766+00	::ffff:172.18.0.1	axios/1.16.0	warning
180	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:20:57.892836+00	::ffff:172.18.0.1	axios/1.16.0	info
181	\N	LOGIN_NEW_IP	3	{"email": "reviewer@test.com", "current_ip": "::ffff:172.18.0.1", "previous_ip": "172.18.0.1"}	2026-05-10 12:20:57.983937+00	::ffff:172.18.0.1	axios/1.16.0	warning
183	\N	ACCESS_DENIED_403	3	{"path": "/api/users", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:20:57.992859+00	::ffff:172.18.0.1	axios/1.16.0	warning
184	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:20:58.004978+00	::ffff:172.18.0.1	axios/1.16.0	warning
185	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:20:58.084664+00	::ffff:172.18.0.1	axios/1.16.0	info
186	\N	ACCESS_DENIED_403	3	{"path": "/api/logs", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:20:58.090099+00	::ffff:172.18.0.1	axios/1.16.0	warning
187	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:45.986984+00	::ffff:172.18.0.1	axios/1.16.0	info
188	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:31:46.087544+00	::ffff:172.18.0.1	axios/1.16.0	warning
189	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:46.175454+00	::ffff:172.18.0.1	axios/1.16.0	info
190	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:31:46.259022+00	::ffff:172.18.0.1	axios/1.16.0	info
191	\N	ACCESS_DENIED_403	3	{"path": "/api/users", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:31:46.264095+00	::ffff:172.18.0.1	axios/1.16.0	warning
192	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:31:46.274434+00	::ffff:172.18.0.1	axios/1.16.0	warning
193	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:31:46.351142+00	::ffff:172.18.0.1	axios/1.16.0	info
194	\N	ACCESS_DENIED_403	3	{"path": "/api/logs", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:31:46.356628+00	::ffff:172.18.0.1	axios/1.16.0	warning
195	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:46.526163+00	::ffff:172.18.0.1	axios/1.16.0	info
196	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:31:46.557963+00	::ffff:172.18.0.1	axios/1.16.0	warning
197	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:31:46.634037+00	::ffff:172.18.0.1	axios/1.16.0	info
198	\N	ACCESS_DENIED_403	3	{"path": "/api/incidents", "role": "Reviewer", "method": "GET", "required": ["Admin"]}	2026-05-10 12:31:46.638643+00	::ffff:172.18.0.1	axios/1.16.0	warning
199	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:31:46.708397+00	::ffff:172.18.0.1	axios/1.16.0	warning
200	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:31:46.782144+00	::ffff:172.18.0.1	axios/1.16.0	warning
201	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:31:46.868715+00	::ffff:172.18.0.1	axios/1.16.0	warning
202	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:31:46.938242+00	::ffff:172.18.0.1	axios/1.16.0	warning
203	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:31:47.010032+00	::ffff:172.18.0.1	axios/1.16.0	warning
204	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:31:54.985765+00	::ffff:172.18.0.1	axios/1.16.0	warning
205	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 2}	2026-05-10 12:31:55.078811+00	::ffff:172.18.0.1	axios/1.16.0	warning
206	\N	ACCOUNT_LOCKED	3	{"email": "reviewer@test.com", "attempts": 3, "locked_until": "2026-05-10T12:46:55.147Z"}	2026-05-10 12:31:55.151153+00	::ffff:172.18.0.1	axios/1.16.0	critical
207	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:55.308804+00	::ffff:172.18.0.1	axios/1.16.0	info
208	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:55.405242+00	::ffff:172.18.0.1	axios/1.16.0	info
209	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:31:55.427337+00	::ffff:172.18.0.1	axios/1.16.0	warning
210	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:55.506398+00	::ffff:172.18.0.1	axios/1.16.0	info
211	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:31:55.673986+00	::ffff:172.18.0.1	axios/1.16.0	warning
212	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:55.755498+00	::ffff:172.18.0.1	axios/1.16.0	info
213	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:31:55.759996+00	::ffff:172.18.0.1	axios/1.16.0	warning
214	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:31:55.765667+00	::ffff:172.18.0.1	axios/1.16.0	warning
215	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:31:55.774157+00	::ffff:172.18.0.1	axios/1.16.0	warning
216	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:31:55.780461+00	::ffff:172.18.0.1	axios/1.16.0	warning
217	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:31:55.786231+00	::ffff:172.18.0.1	axios/1.16.0	warning
218	\N	LOGIN_FAILURE	\N	{"email": "email_qui_nexiste_pas_xyz999@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:31:55.928267+00	::ffff:172.18.0.1	axios/1.16.0	warning
219	\N	LOGIN_FAILURE	1	{"email": "admin@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:31:56.000335+00	::ffff:172.18.0.1	axios/1.16.0	warning
220	\N	LOGIN_FAILURE	\N	{"email": "email_inconnu_abc123@test.invalid", "reason": "user_not_found"}	2026-05-10 12:31:56.081164+00	::ffff:172.18.0.1	axios/1.16.0	warning
221	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:31:56.154534+00	::ffff:172.18.0.1	axios/1.16.0	warning
222	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:31:56.224664+00	::ffff:172.18.0.1	axios/1.16.0	warning
223	\N	LOGIN_FAILURE	\N	{"email": "'; DROP TABLE users;--", "reason": "user_not_found"}	2026-05-10 12:31:56.605743+00	::ffff:172.18.0.1	axios/1.16.0	warning
224	\N	ACCESS_DENIED_401	\N	{"path": "/api/users", "method": "GET"}	2026-05-10 12:31:57.080891+00	::ffff:172.18.0.1	axios/1.16.0	warning
225	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:31:57.084522+00	::ffff:172.18.0.1	axios/1.16.0	warning
226	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:31:57.091926+00	::ffff:172.18.0.1	axios/1.16.0	warning
227	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:31:57.097119+00	::ffff:172.18.0.1	axios/1.16.0	warning
228	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:31:57.100361+00	::ffff:172.18.0.1	axios/1.16.0	warning
229	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:57.446368+00	::ffff:172.18.0.1	axios/1.16.0	info
230	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:31:57.606021+00	::ffff:172.18.0.1	axios/1.16.0	info
231	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:40.451508+00	::ffff:172.18.0.1	axios/1.16.0	info
232	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:51:40.557097+00	::ffff:172.18.0.1	axios/1.16.0	warning
233	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:40.665988+00	::ffff:172.18.0.1	axios/1.16.0	info
234	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:51:40.751222+00	::ffff:172.18.0.1	axios/1.16.0	info
235	\N	ACCESS_DENIED_403	3	{"path": "/api/users", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:51:40.756955+00	::ffff:172.18.0.1	axios/1.16.0	warning
236	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:51:40.770188+00	::ffff:172.18.0.1	axios/1.16.0	warning
237	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:51:40.86008+00	::ffff:172.18.0.1	axios/1.16.0	info
238	\N	ACCESS_DENIED_403	3	{"path": "/api/logs", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:51:40.865225+00	::ffff:172.18.0.1	axios/1.16.0	warning
239	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:51:41.0511+00	::ffff:172.18.0.1	axios/1.16.0	warning
240	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:41.124782+00	::ffff:172.18.0.1	axios/1.16.0	info
241	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:51:41.129989+00	::ffff:172.18.0.1	axios/1.16.0	warning
242	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:45.234304+00	::ffff:172.18.0.1	axios/1.16.0	info
243	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:51:45.264572+00	::ffff:172.18.0.1	axios/1.16.0	warning
244	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:51:45.34736+00	::ffff:172.18.0.1	axios/1.16.0	info
245	\N	ACCESS_DENIED_403	3	{"path": "/api/incidents", "role": "Reviewer", "method": "GET", "required": ["Admin"]}	2026-05-10 12:51:45.352057+00	::ffff:172.18.0.1	axios/1.16.0	warning
246	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:51:45.425723+00	::ffff:172.18.0.1	axios/1.16.0	warning
247	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:51:45.495694+00	::ffff:172.18.0.1	axios/1.16.0	warning
248	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:51:45.565086+00	::ffff:172.18.0.1	axios/1.16.0	warning
249	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:51:45.635555+00	::ffff:172.18.0.1	axios/1.16.0	warning
250	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:51:45.705162+00	::ffff:172.18.0.1	axios/1.16.0	warning
251	\N	LOGIN_FAILURE	\N	{"email": "email_qui_nexiste_pas_xyz999@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:51:47.873816+00	::ffff:172.18.0.1	axios/1.16.0	warning
252	\N	LOGIN_FAILURE	1	{"email": "admin@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:51:47.951404+00	::ffff:172.18.0.1	axios/1.16.0	warning
253	\N	LOGIN_FAILURE	\N	{"email": "email_inconnu_abc123@test.invalid", "reason": "user_not_found"}	2026-05-10 12:51:48.024902+00	::ffff:172.18.0.1	axios/1.16.0	warning
254	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:51:48.099636+00	::ffff:172.18.0.1	axios/1.16.0	warning
255	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:51:48.1702+00	::ffff:172.18.0.1	axios/1.16.0	warning
256	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:48.345249+00	::ffff:172.18.0.1	axios/1.16.0	info
257	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:48.447611+00	::ffff:172.18.0.1	axios/1.16.0	info
258	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:51:48.468996+00	::ffff:172.18.0.1	axios/1.16.0	warning
259	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:48.565887+00	::ffff:172.18.0.1	axios/1.16.0	info
260	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:51:48.727642+00	::ffff:172.18.0.1	axios/1.16.0	warning
261	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 2}	2026-05-10 12:51:48.801269+00	::ffff:172.18.0.1	axios/1.16.0	warning
262	\N	ACCOUNT_LOCKED	3	{"email": "reviewer@test.com", "attempts": 3, "locked_until": "2026-05-10T13:06:48.871Z"}	2026-05-10 12:51:48.875215+00	::ffff:172.18.0.1	axios/1.16.0	critical
263	\N	LOGIN_FAILURE	\N	{"email": "'; DROP TABLE users;--", "reason": "user_not_found"}	2026-05-10 12:51:49.306666+00	::ffff:172.18.0.1	axios/1.16.0	warning
264	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:49.619406+00	::ffff:172.18.0.1	axios/1.16.0	info
265	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:51:49.987902+00	::ffff:172.18.0.1	axios/1.16.0	info
266	\N	ACCESS_DENIED_401	\N	{"path": "/api/users", "method": "GET"}	2026-05-10 12:51:50.346184+00	::ffff:172.18.0.1	axios/1.16.0	warning
267	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:51:50.349986+00	::ffff:172.18.0.1	axios/1.16.0	warning
268	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:51:50.373577+00	::ffff:172.18.0.1	axios/1.16.0	warning
269	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:51:50.37815+00	::ffff:172.18.0.1	axios/1.16.0	warning
270	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:51:50.382362+00	::ffff:172.18.0.1	axios/1.16.0	warning
271	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:56:47.815035+00	::ffff:172.18.0.1	axios/1.16.0	info
272	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:56:47.918047+00	::ffff:172.18.0.1	axios/1.16.0	warning
273	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:56:48.017313+00	::ffff:172.18.0.1	axios/1.16.0	info
274	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:56:48.102714+00	::ffff:172.18.0.1	axios/1.16.0	info
275	\N	ACCESS_DENIED_403	3	{"path": "/api/users", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:56:48.107903+00	::ffff:172.18.0.1	axios/1.16.0	warning
276	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:56:48.118935+00	::ffff:172.18.0.1	axios/1.16.0	warning
277	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:56:48.193795+00	::ffff:172.18.0.1	axios/1.16.0	info
278	\N	ACCESS_DENIED_403	3	{"path": "/api/logs", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:56:48.198032+00	::ffff:172.18.0.1	axios/1.16.0	warning
279	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:04.924934+00	::ffff:172.18.0.1	axios/1.16.0	info
280	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:57:04.967138+00	::ffff:172.18.0.1	axios/1.16.0	warning
281	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:57:05.04458+00	::ffff:172.18.0.1	axios/1.16.0	info
282	\N	ACCESS_DENIED_403	3	{"path": "/api/incidents", "role": "Reviewer", "method": "GET", "required": ["Admin"]}	2026-05-10 12:57:05.049312+00	::ffff:172.18.0.1	axios/1.16.0	warning
283	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:05.1198+00	::ffff:172.18.0.1	axios/1.16.0	warning
284	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:05.206216+00	::ffff:172.18.0.1	axios/1.16.0	warning
285	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:05.27612+00	::ffff:172.18.0.1	axios/1.16.0	warning
286	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:05.346765+00	::ffff:172.18.0.1	axios/1.16.0	warning
287	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:05.416379+00	::ffff:172.18.0.1	axios/1.16.0	warning
288	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:07.626977+00	::ffff:172.18.0.1	axios/1.16.0	info
289	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:07.725606+00	::ffff:172.18.0.1	axios/1.16.0	warning
290	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:07.807737+00	::ffff:172.18.0.1	axios/1.16.0	info
291	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:57:07.892324+00	::ffff:172.18.0.1	axios/1.16.0	info
292	\N	ACCESS_DENIED_403	3	{"path": "/api/users", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:57:07.89899+00	::ffff:172.18.0.1	axios/1.16.0	warning
293	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:57:07.914607+00	::ffff:172.18.0.1	axios/1.16.0	warning
294	\N	LOGIN_SUCCESS	3	{"ip": "::ffff:172.18.0.1", "role": "Reviewer", "email": "reviewer@test.com"}	2026-05-10 12:57:07.996294+00	::ffff:172.18.0.1	axios/1.16.0	info
295	\N	ACCESS_DENIED_403	3	{"path": "/api/logs", "role": "Reviewer", "method": "GET", "required": ["Admin", "Ing. Qualité"]}	2026-05-10 12:57:08.000255+00	::ffff:172.18.0.1	axios/1.16.0	warning
296	\N	LOGIN_FAILURE	\N	{"email": "email_qui_nexiste_pas_xyz999@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:08.119176+00	::ffff:172.18.0.1	axios/1.16.0	warning
297	\N	LOGIN_FAILURE	1	{"email": "admin@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:57:08.19375+00	::ffff:172.18.0.1	axios/1.16.0	warning
298	\N	LOGIN_FAILURE	\N	{"email": "email_inconnu_abc123@test.invalid", "reason": "user_not_found"}	2026-05-10 12:57:08.264087+00	::ffff:172.18.0.1	axios/1.16.0	warning
299	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:57:08.336195+00	::ffff:172.18.0.1	axios/1.16.0	warning
300	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:57:08.406098+00	::ffff:172.18.0.1	axios/1.16.0	warning
301	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:08.568479+00	::ffff:172.18.0.1	axios/1.16.0	info
302	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:08.669466+00	::ffff:172.18.0.1	axios/1.16.0	info
303	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:57:08.688079+00	::ffff:172.18.0.1	axios/1.16.0	warning
304	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:08.765242+00	::ffff:172.18.0.1	axios/1.16.0	info
305	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:57:08.889952+00	::ffff:172.18.0.1	axios/1.16.0	warning
306	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 2}	2026-05-10 12:57:08.974041+00	::ffff:172.18.0.1	axios/1.16.0	warning
307	\N	ACCOUNT_LOCKED	3	{"email": "reviewer@test.com", "attempts": 3, "locked_until": "2026-05-10T13:12:09.043Z"}	2026-05-10 12:57:09.049105+00	::ffff:172.18.0.1	axios/1.16.0	critical
308	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:57:09.439692+00	::ffff:172.18.0.1	axios/1.16.0	warning
309	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:09.523289+00	::ffff:172.18.0.1	axios/1.16.0	info
310	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:57:09.527605+00	::ffff:172.18.0.1	axios/1.16.0	warning
311	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:09.717612+00	::ffff:172.18.0.1	axios/1.16.0	info
312	\N	LOGIN_FAILURE	\N	{"email": "'; DROP TABLE users;--", "reason": "user_not_found"}	2026-05-10 12:57:09.934073+00	::ffff:172.18.0.1	axios/1.16.0	warning
313	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:10.37011+00	::ffff:172.18.0.1	axios/1.16.0	info
314	\N	ACCESS_DENIED_401	\N	{"path": "/api/users", "method": "GET"}	2026-05-10 12:57:10.530783+00	::ffff:172.18.0.1	axios/1.16.0	warning
315	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:57:10.534568+00	::ffff:172.18.0.1	axios/1.16.0	warning
316	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:57:10.553049+00	::ffff:172.18.0.1	axios/1.16.0	warning
317	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:57:10.570443+00	::ffff:172.18.0.1	axios/1.16.0	warning
318	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:57:10.573523+00	::ffff:172.18.0.1	axios/1.16.0	warning
319	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:30.48731+00	::ffff:172.18.0.1	axios/1.16.0	info
320	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:57:30.57503+00	::ffff:172.18.0.1	axios/1.16.0	warning
321	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:30.66348+00	::ffff:172.18.0.1	axios/1.16.0	warning
322	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:30.73567+00	::ffff:172.18.0.1	axios/1.16.0	warning
323	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:30.806755+00	::ffff:172.18.0.1	axios/1.16.0	warning
324	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:30.879453+00	::ffff:172.18.0.1	axios/1.16.0	warning
325	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:30.957469+00	::ffff:172.18.0.1	axios/1.16.0	warning
326	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:33.204774+00	::ffff:172.18.0.1	axios/1.16.0	info
327	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:33.305402+00	::ffff:172.18.0.1	axios/1.16.0	warning
328	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:33.396483+00	::ffff:172.18.0.1	axios/1.16.0	info
329	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:57:33.424162+00	::ffff:172.18.0.1	axios/1.16.0	warning
330	\N	LOGIN_FAILURE	\N	{"email": "email_qui_nexiste_pas_xyz999@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:57:33.569855+00	::ffff:172.18.0.1	axios/1.16.0	warning
331	\N	LOGIN_FAILURE	1	{"email": "admin@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:57:33.645962+00	::ffff:172.18.0.1	axios/1.16.0	warning
332	\N	LOGIN_FAILURE	\N	{"email": "email_inconnu_abc123@test.invalid", "reason": "user_not_found"}	2026-05-10 12:57:33.722071+00	::ffff:172.18.0.1	axios/1.16.0	warning
333	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:57:33.792126+00	::ffff:172.18.0.1	axios/1.16.0	warning
334	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:57:33.864919+00	::ffff:172.18.0.1	axios/1.16.0	warning
335	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:34.018502+00	::ffff:172.18.0.1	axios/1.16.0	info
336	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:34.133127+00	::ffff:172.18.0.1	axios/1.16.0	info
337	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:57:34.153517+00	::ffff:172.18.0.1	axios/1.16.0	warning
338	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:34.235108+00	::ffff:172.18.0.1	axios/1.16.0	info
339	\N	LOGIN_FAILURE	\N	{"email": "'; DROP TABLE users;--", "reason": "user_not_found"}	2026-05-10 12:57:34.491053+00	::ffff:172.18.0.1	axios/1.16.0	warning
340	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:57:34.760348+00	::ffff:172.18.0.1	axios/1.16.0	warning
341	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:34.839687+00	::ffff:172.18.0.1	axios/1.16.0	info
342	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:57:34.844122+00	::ffff:172.18.0.1	axios/1.16.0	warning
343	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:57:34.848794+00	::ffff:172.18.0.1	axios/1.16.0	warning
344	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:57:34.857289+00	::ffff:172.18.0.1	axios/1.16.0	warning
345	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:57:34.864038+00	::ffff:172.18.0.1	axios/1.16.0	warning
346	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:57:34.869289+00	::ffff:172.18.0.1	axios/1.16.0	warning
347	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:57:35.36252+00	::ffff:172.18.0.1	axios/1.16.0	info
348	\N	ACCESS_DENIED_401	\N	{"path": "/api/users", "method": "GET"}	2026-05-10 12:57:35.881785+00	::ffff:172.18.0.1	axios/1.16.0	warning
349	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:57:35.886102+00	::ffff:172.18.0.1	axios/1.16.0	warning
350	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:57:35.894048+00	::ffff:172.18.0.1	axios/1.16.0	warning
351	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:57:35.898936+00	::ffff:172.18.0.1	axios/1.16.0	warning
352	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:57:35.902343+00	::ffff:172.18.0.1	axios/1.16.0	warning
353	\N	ACCESS_DENIED_401	\N	{"path": "/api/users", "method": "GET"}	2026-05-10 12:58:21.738415+00	::ffff:172.18.0.1	axios/1.16.0	warning
354	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:58:21.749799+00	::ffff:172.18.0.1	axios/1.16.0	warning
355	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:58:21.756169+00	::ffff:172.18.0.1	axios/1.16.0	warning
356	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:58:21.760308+00	::ffff:172.18.0.1	axios/1.16.0	warning
357	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:58:21.759211+00	::ffff:172.18.0.1	axios/1.16.0	warning
358	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:59:18.655323+00	::ffff:172.18.0.1	axios/1.16.0	warning
359	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:18.735433+00	::ffff:172.18.0.1	axios/1.16.0	info
360	\N	ACCESS_DENIED_401	\N	{"path": "/api/documents", "method": "POST"}	2026-05-10 12:59:18.748784+00	::ffff:172.18.0.1	axios/1.16.0	warning
361	\N	LOGIN_FAILURE	\N	{"email": "'; DROP TABLE users;--", "reason": "user_not_found"}	2026-05-10 12:59:18.963178+00	::ffff:172.18.0.1	axios/1.16.0	warning
362	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:19.43104+00	::ffff:172.18.0.1	axios/1.16.0	info
363	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:19.531461+00	::ffff:172.18.0.1	axios/1.16.0	info
364	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:59:19.561445+00	::ffff:172.18.0.1	axios/1.16.0	warning
365	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:19.648209+00	::ffff:172.18.0.1	axios/1.16.0	info
366	\N	LOGIN_FAILURE	\N	{"email": "email_qui_nexiste_pas_xyz999@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:59:19.788075+00	::ffff:172.18.0.1	axios/1.16.0	warning
367	\N	LOGIN_FAILURE	1	{"email": "admin@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:59:19.877534+00	::ffff:172.18.0.1	axios/1.16.0	warning
368	\N	LOGIN_FAILURE	\N	{"email": "email_inconnu_abc123@test.invalid", "reason": "user_not_found"}	2026-05-10 12:59:19.968385+00	::ffff:172.18.0.1	axios/1.16.0	warning
369	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:59:20.055632+00	::ffff:172.18.0.1	axios/1.16.0	warning
370	\N	LOGIN_FAILURE	\N	{"email": "test@test.invalid", "reason": "user_not_found"}	2026-05-10 12:59:20.137737+00	::ffff:172.18.0.1	axios/1.16.0	warning
371	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 1}	2026-05-10 12:59:20.278975+00	::ffff:172.18.0.1	axios/1.16.0	warning
372	\N	LOGIN_FAILURE	3	{"email": "reviewer@test.com", "reason": "wrong_password", "attempt": 2}	2026-05-10 12:59:20.363063+00	::ffff:172.18.0.1	axios/1.16.0	warning
373	\N	ACCOUNT_LOCKED	3	{"email": "reviewer@test.com", "attempts": 3, "locked_until": "2026-05-10T13:14:20.437Z"}	2026-05-10 12:59:20.443018+00	::ffff:172.18.0.1	axios/1.16.0	critical
374	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:20.605315+00	::ffff:172.18.0.1	axios/1.16.0	info
375	\N	LOGIN_FAILURE	\N	{"email": "audit_test_xyz@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:59:20.704487+00	::ffff:172.18.0.1	axios/1.16.0	warning
376	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:20.788644+00	::ffff:172.18.0.1	axios/1.16.0	info
377	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:59:20.811952+00	::ffff:172.18.0.1	axios/1.16.0	warning
378	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:20.963626+00	::ffff:172.18.0.1	axios/1.16.0	info
379	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:59:21.016436+00	::ffff:172.18.0.1	axios/1.16.0	warning
380	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:59:21.107576+00	::ffff:172.18.0.1	axios/1.16.0	warning
381	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:59:21.181359+00	::ffff:172.18.0.1	axios/1.16.0	warning
382	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:59:21.256464+00	::ffff:172.18.0.1	axios/1.16.0	warning
383	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:59:21.328457+00	::ffff:172.18.0.1	axios/1.16.0	warning
384	\N	LOGIN_FAILURE	\N	{"email": "bruteforce_detect_test@nowhere.invalid", "reason": "user_not_found"}	2026-05-10 12:59:21.403597+00	::ffff:172.18.0.1	axios/1.16.0	warning
385	\N	ACCESS_DENIED_401	\N	{"path": "/api/users", "method": "GET"}	2026-05-10 12:59:25.645933+00	::ffff:172.18.0.1	axios/1.16.0	warning
386	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:59:25.650961+00	::ffff:172.18.0.1	axios/1.16.0	warning
387	\N	ACCESS_DENIED_401	\N	{"path": "/api/incidents", "method": "GET"}	2026-05-10 12:59:25.662251+00	::ffff:172.18.0.1	axios/1.16.0	warning
388	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:59:25.66709+00	::ffff:172.18.0.1	axios/1.16.0	warning
389	\N	ACCESS_DENIED_401	\N	{"path": "/api/logs", "method": "GET"}	2026-05-10 12:59:25.671216+00	::ffff:172.18.0.1	axios/1.16.0	warning
390	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:25.989704+00	::ffff:172.18.0.1	axios/1.16.0	info
391	\N	LOGIN_SUCCESS	1	{"ip": "::ffff:172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 12:59:26.271052+00	::ffff:172.18.0.1	axios/1.16.0	info
392	\N	LOGIN_NEW_IP	1	{"email": "admin@test.com", "current_ip": "172.18.0.1", "previous_ip": "::ffff:172.18.0.1"}	2026-05-10 13:27:21.974587+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	warning
393	\N	LOGIN_SUCCESS	1	{"ip": "172.18.0.1", "role": "Admin", "email": "admin@test.com"}	2026-05-10 13:27:22.008003+00	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	info
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.notifications (id, user_id, document_id, message, type, is_read, created_at) FROM stdin;
1	1	2	[TR0001_Trame_-] "Trame" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "test".	version	f	2026-05-01 17:28:10.312955+00
2	2	2	[TR0001_Trame_-] "Trame" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "test".	version	f	2026-05-01 17:28:10.327588+00
3	1	2	[TR0001_Trame_A] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 17:34:30.952098+00
4	2	2	[TR0001_Trame_A] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 17:34:30.95944+00
5	3	2	[TR0001_Trame_A] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	t	2026-05-01 17:34:30.97073+00
6	1	4	[TR0002_Trame_-] "Trame" — date de révision dépassée depuis 37 jour(s) (prévue le 25/03/2026). Une révision est requise.	expiration	f	2026-05-01 21:04:22.269667+00
7	1	5	[PR0002_Procedure_-] "Procédure" — date de révision dépassée depuis 9 jour(s) (prévue le 22/04/2026). Une révision est requise.	expiration	f	2026-05-01 21:05:43.896373+00
8	1	3	[PR0001_Procedure_-] "Procédure" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:09:24.143972+00
9	2	3	[PR0001_Procedure_-] "Procédure" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:09:24.14983+00
10	4	3	[PR0001_Procedure_-] "Procédure" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:09:24.152826+00
11	3	3	[PR0001_Procedure_-] "Procédure" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:09:24.158134+00
12	3	2	[TR0001_Trame_A1] "Trame" diffusé par Ing Qualité (Ing. Qualité) — disponible à la consultation.	version	f	2026-05-01 21:10:17.989108+00
13	4	2	[TR0001_Trame_A1] "Trame" diffusé par Ing Qualité (Ing. Qualité) — disponible à la consultation.	version	f	2026-05-01 21:10:18.00067+00
14	1	2	[TR0001_Trame_A1] "Trame" marqué Obsolète par Ing Qualité (Ing. Qualité). Ce document ne doit plus être utilisé.	expiration	f	2026-05-01 21:10:18.212458+00
15	1	6	[GU0001_Guide_-] "Guide" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:12:34.668795+00
17	4	6	[GU0001_Guide_-] "Guide" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:12:34.679859+00
18	3	6	[GU0001_Guide_-] "Guide" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:12:34.682194+00
19	1	4	[TR0002_Trame_-] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:12:39.001493+00
20	2	4	[TR0002_Trame_-] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:12:39.008901+00
21	4	4	[TR0002_Trame_-] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:12:39.012476+00
22	3	4	[TR0002_Trame_-] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-01 21:12:39.015029+00
48	1	7	[TR0003_Trame_-] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 09:57:31.769264+00
49	2	7	[TR0003_Trame_-] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 09:57:31.777911+00
50	4	7	[TR0003_Trame_-] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 09:57:31.786317+00
52	1	7	[TR0003_Trame_-] "Trame" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "ttesstt".	version	f	2026-05-03 09:58:02.358537+00
53	2	7	[TR0003_Trame_-] "Trame" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "ttesstt".	version	f	2026-05-03 09:58:02.370276+00
54	1	8	[GU0002_Guide_-] "Guide" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "tt".	version	f	2026-05-03 10:07:47.283786+00
55	2	8	[GU0002_Guide_-] "Guide" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "tt".	version	f	2026-05-03 10:07:47.299162+00
56	1	8	[GU0002_Guide_A] "Guide" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 10:29:48.949806+00
57	2	8	[GU0002_Guide_A] "Guide" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 10:29:48.96173+00
58	4	8	[GU0002_Guide_A] "Guide" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 10:29:48.966846+00
59	3	8	[GU0002_Guide_A] "Guide" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 10:29:48.976293+00
16	2	6	[GU0001_Guide_-] "Guide" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	t	2026-05-01 21:12:34.675925+00
60	1	4	[TR0002_Trame_-] "Trame" diffusé par Ing Qualité (Ing. Qualité) — disponible à la consultation.	version	f	2026-05-03 10:57:59.331124+00
61	4	4	[TR0002_Trame_-] "Trame" diffusé par Ing Qualité (Ing. Qualité) — disponible à la consultation.	version	f	2026-05-03 10:57:59.33838+00
62	3	4	[TR0002_Trame_-] "Trame" diffusé par Ing Qualité (Ing. Qualité) — disponible à la consultation.	version	f	2026-05-03 10:57:59.347633+00
63	2	4	[TR0002_Trame_-] "Trame" diffusé par Ing Qualité (Ing. Qualité) — disponible à la consultation.	version	f	2026-05-03 10:57:59.355634+00
64	1	5	[PR0002_Procedure_-] "Procédure" — appel en relecture émis par Admin (Admin). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 14:53:00.513564+00
65	2	5	[PR0002_Procedure_-] "Procédure" — appel en relecture émis par Admin (Admin). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 14:53:00.522199+00
66	3	5	[PR0002_Procedure_-] "Procédure" — appel en relecture émis par Admin (Admin). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 14:53:00.525467+00
67	4	5	[PR0002_Procedure_-] "Procédure" — appel en relecture émis par Admin (Admin). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-03 14:53:00.528913+00
68	1	9	[TR0004_Trame_-] "Trame" — appel en relecture émis par Admin (Admin). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-06 09:47:24.060454+00
69	2	9	[TR0004_Trame_-] "Trame" — appel en relecture émis par Admin (Admin). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-06 09:47:24.071775+00
70	3	9	[TR0004_Trame_-] "Trame" — appel en relecture émis par Admin (Admin). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-06 09:47:24.079464+00
71	4	9	[TR0004_Trame_-] "Trame" — appel en relecture émis par Admin (Admin). Une nouvelle version est disponible pour relecture.	validation	f	2026-05-06 09:47:24.084987+00
72	2	9	[TR0004_Trame_-] "Trame" — nouvelle version (A) créée par Admin (Admin). Résumé : "test version".	version	f	2026-05-06 09:47:43.541075+00
73	1	9	[TR0004_Trame_-] "Trame" — nouvelle version (A) créée par Admin (Admin). Résumé : "test version".	version	f	2026-05-06 09:47:43.558689+00
74	2	10	[GU0003_Guide_-] "Guide" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "te".	version	f	2026-05-06 14:33:19.426496+00
75	1	10	[GU0003_Guide_-] "Guide" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "te".	version	f	2026-05-06 14:33:19.447984+00
51	3	7	[TR0003_Trame_-] "Trame" — appel en relecture émis par Ing Qualité (Ing. Qualité). Une nouvelle version est disponible pour relecture.	validation	t	2026-05-03 09:57:31.794551+00
76	1	11	[MN0001_Manuel_-] "Manuel" — date de révision dépassée depuis 21 jour(s) (prévue le 17/04/2026). Une révision est requise.	expiration	f	2026-05-08 14:47:39.620252+00
77	2	11	[MN0001_Manuel_-] "Manuel" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "vvvvv".	version	f	2026-05-08 14:50:40.961808+00
78	1	11	[MN0001_Manuel_-] "Manuel" — nouvelle version (A) créée par Ing Qualité (Ing. Qualité). Résumé : "vvvvv".	version	f	2026-05-08 14:50:40.973747+00
\.


--
-- Data for Name: processes; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.processes (id, code, strategic_process, main_process, sub_process) FROM stdin;
1	CDP	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	Concevoir_Developper_Produits
2	FESI	01_PROCESSUS_STRATEGIQUE	Faire_Evoluer_Securiser_SI	Faire_Evoluer_Securiser_SI
3	FPS	01_PROCESSUS_STRATEGIQUE	Fournir_Prestations_Service	Fournir_Prestations_Service
4	GIET	01_PROCESSUS_STRATEGIQUE	Gerer_Infrastructure_Environnement_Travail	Gerer_Infrastructure_Environnement_Travail
5	MAL	02_PROCESSUS_SUPPORT	Maitriser_Achats_Logistique	Maitriser_Achats_Logistique
6	MSST	02_PROCESSUS_SUPPORT	Manager_Sante_Securite_Travail	Manager_Sante_Securite_Travail
7	MMR	02_PROCESSUS_SUPPORT	Manager_Motiver_Ressources	Manager_Motiver_Ressources
8	PE	02_PROCESSUS_SUPPORT	Piloter_l_Entreprise	Piloter_l_Entreprise
9	CDP-PS	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PS_Processus_Strategique
10	CDP-MC	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Mecanique
11	CDP-DL	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Developpement_Logiciel
12	CDP-DO	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Conception_Developpement_Outillages
13	CDP-EL	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Electronique
14	CDP-QT	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Qualification_Thermomecanique
15	CDP-VA	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Validation
16	CDP-IVS	01_PROCESSUS_STRATEGIQUE	Concevoir_Developper_Produits	PM_Industrialisation_Vie_Serie
\.


--
-- Data for Name: reset_tokens; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.reset_tokens (id, user_id, token, expires_at, used, created_at) FROM stdin;
1	4	ad75f466c223297a4375d2271497d243b0035f9c4f935883ea6f7011f0ba2cea	2026-05-06 09:24:46.053+00	t	2026-05-06 08:24:46.0548+00
2	4	e3ea06b2094565f9ff591f047dc9d1c4bc3baff7ac26ef8f9909ca57fcf2f7ff	2026-05-08 15:18:26.742+00	f	2026-05-08 14:18:26.743802+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.roles (id, name, description) FROM stdin;
1	Admin	Accès complet — gestion utilisateurs, archivage, workflow
2	Ing. Qualité	Création, modification et soumission de documents
3	Reviewer	Relecture et validation des documents
\.


--
-- Data for Name: security_incidents; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.security_incidents (id, type, severity, description, ip_address, user_id, detected_at, status, resolved_at, resolved_by, notes) FROM stdin;
1	BRUTE_FORCE	critical	Tentative de brute-force détectée : 6 échecs de connexion depuis l'IP 172.18.0.1 en moins d'une heure.	172.18.0.1	1	2026-05-01 17:14:57.1294+00	open	\N	\N	\N
2	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 1) après trop de tentatives échouées.	172.18.0.1	1	2026-05-01 17:14:57.147474+00	open	\N	\N	\N
3	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	172.18.0.1	3	2026-05-01 18:42:05.911597+00	open	\N	\N	\N
4	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	172.18.0.1	3	2026-05-01 20:35:39.372718+00	open	\N	\N	\N
5	BRUTE_FORCE	critical	Tentative de brute-force détectée : 8 échecs de connexion depuis l'IP ::ffff:172.18.0.1 en moins d'une heure.	::ffff:172.18.0.1	\N	2026-05-06 09:05:48.215634+00	open	\N	\N	\N
6	SUSPICIOUS_LOGIN	warning	Connexion depuis une nouvelle IP pour l'utilisateur ID 1.	::ffff:172.18.0.1	1	2026-05-06 09:05:48.226439+00	open	\N	\N	\N
7	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 1) après trop de tentatives échouées.	::ffff:172.18.0.1	1	2026-05-06 09:06:58.964979+00	open	\N	\N	\N
8	BRUTE_FORCE	critical	Tentative de brute-force détectée : 48 échecs de connexion depuis l'IP ::ffff:172.18.0.1 en moins d'une heure.	::ffff:172.18.0.1	3	2026-05-06 10:14:57.056318+00	open	\N	\N	\N
9	SUSPICIOUS_LOGIN	warning	Connexion depuis une nouvelle IP pour l'utilisateur ID 1.	172.18.0.1	1	2026-05-06 10:14:57.068272+00	open	\N	\N	\N
10	SUSPICIOUS_LOGIN	warning	Connexion depuis une nouvelle IP pour l'utilisateur ID 3.	::ffff:172.18.0.1	3	2026-05-06 10:14:57.071615+00	open	\N	\N	\N
11	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	::ffff:172.18.0.1	3	2026-05-06 10:14:57.074936+00	open	\N	\N	\N
12	BRUTE_FORCE	critical	Tentative de brute-force détectée : 15 échecs de connexion depuis l'IP ::ffff:172.18.0.1 en moins d'une heure.	::ffff:172.18.0.1	3	2026-05-06 13:15:24.61523+00	open	\N	\N	\N
13	SUSPICIOUS_LOGIN	warning	Connexion depuis une nouvelle IP pour l'utilisateur ID 1.	::ffff:172.18.0.1	1	2026-05-06 13:15:24.622645+00	open	\N	\N	\N
14	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	::ffff:172.18.0.1	3	2026-05-06 13:15:24.626436+00	open	\N	\N	\N
15	BRUTE_FORCE	critical	Tentative de brute-force détectée : 226 échecs de connexion depuis l'IP ::ffff:172.18.0.1 en moins d'une heure.	::ffff:172.18.0.1	3	2026-05-06 14:16:10.978039+00	open	\N	\N	\N
16	SUSPICIOUS_LOGIN	warning	Connexion depuis une nouvelle IP pour l'utilisateur ID 1.	::ffff:172.18.0.1	1	2026-05-06 14:16:10.988468+00	open	\N	\N	\N
17	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	::ffff:172.18.0.1	3	2026-05-06 14:16:10.991923+00	open	\N	\N	\N
18	ACCESS_ABUSE	warning	Abus d'accès détecté : 22 refus d'accès (403) pour l'utilisateur ID 3 en moins d'une heure.	::ffff:172.18.0.1	3	2026-05-06 14:32:53.437782+00	open	\N	\N	\N
19	BRUTE_FORCE	critical	Tentative de brute-force détectée : 15 échecs de connexion depuis l'IP ::ffff:172.18.0.1 en moins d'une heure.	::ffff:172.18.0.1	3	2026-05-06 15:32:53.0511+00	open	\N	\N	\N
20	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	::ffff:172.18.0.1	3	2026-05-06 15:32:53.069209+00	open	\N	\N	\N
21	BRUTE_FORCE	critical	Tentative de brute-force détectée : 5 échecs de connexion depuis l'IP 172.18.0.1 en moins d'une heure.	172.18.0.1	1	2026-05-07 21:27:18.615322+00	open	\N	\N	\N
22	BRUTE_FORCE	critical	Tentative de brute-force détectée : 30 échecs de connexion depuis l'IP ::ffff:172.18.0.1 en moins d'une heure.	::ffff:172.18.0.1	3	2026-05-07 21:27:18.620529+00	open	\N	\N	\N
23	SUSPICIOUS_LOGIN	warning	Connexion depuis une nouvelle IP pour l'utilisateur ID 1.	::ffff:172.18.0.1	1	2026-05-07 21:27:18.62546+00	open	\N	\N	\N
24	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 1) après trop de tentatives échouées.	172.18.0.1	1	2026-05-07 21:27:18.628892+00	open	\N	\N	\N
25	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	::ffff:172.18.0.1	3	2026-05-07 21:27:18.631553+00	open	\N	\N	\N
26	BRUTE_FORCE	critical	Tentative de brute-force détectée : 30 échecs de connexion depuis l'IP ::ffff:172.18.0.1 en moins d'une heure.	::ffff:172.18.0.1	3	2026-05-07 22:31:02.725292+00	open	\N	\N	\N
27	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	::ffff:172.18.0.1	3	2026-05-07 22:31:02.748081+00	open	\N	\N	\N
28	SUSPICIOUS_LOGIN	warning	Connexion depuis une nouvelle IP pour l'utilisateur ID 3.	172.18.0.1	3	2026-05-08 14:29:18.91596+00	open	\N	\N	\N
29	BRUTE_FORCE	critical	Tentative de brute-force détectée : 28 échecs de connexion depuis l'IP ::ffff:172.18.0.1 en moins d'une heure.	::ffff:172.18.0.1	3	2026-05-10 12:43:34.57032+00	open	\N	\N	\N
30	SUSPICIOUS_LOGIN	warning	Connexion depuis une nouvelle IP pour l'utilisateur ID 1.	::ffff:172.18.0.1	1	2026-05-10 12:43:34.621641+00	open	\N	\N	\N
31	ACCOUNT_LOCKED	critical	Compte verrouillé (ID 3) après trop de tentatives échouées.	::ffff:172.18.0.1	3	2026-05-10 12:43:34.631278+00	open	\N	\N	\N
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.status (id, name) FROM stdin;
1	Brouillon
2	En rédaction
3	En relecture
4	En validation
5	Validé
6	Diffusé
7	Obsolète
8	Archivé
9	Approuvé
14	Appel en relecture
15	En correction
\.


--
-- Data for Name: token_blacklist; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.token_blacklist (jti, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.users (id, name, email, password_hash, role_id, is_active, last_login, requested_role, created_at, last_login_ip, login_attempts, locked_until) FROM stdin;
2	Ing Qualité	ing@test.com	$2b$10$m7oWtolqZVA4r/csfMBf/u7n59GRdctZS4XqraTYu3k8TM720Yc1W	2	t	2026-05-10 12:12:15.574313+00	\N	2026-05-01 17:11:29.396869+00	172.18.0.1	0	\N
4	Moetez Hamzaoui	motezhm40@gmail.com	$2b$10$I545HIRL8IeT9TMl2en3JOQULLv5p82KZE88Am5We/jFCOkbySXKS	3	t	\N	Reviewer	2026-05-01 21:03:21.505708+00	\N	0	\N
3	Reviewer	reviewer@test.com	$2b$10$71O2rjQ4ddPAOTFGi99dx.jD53lN5Th3gSCW1uongwJR07CvcFTnC	3	t	2026-05-10 12:57:07.992097+00	\N	2026-05-01 17:11:29.466352+00	::ffff:172.18.0.1	3	2026-05-10 13:14:20.437+00
1	Admin	admin@test.com	$2b$10$0fmRdfXoytHRmeS0aXnCyu9kP/OZu3t/EIho.WadYNilSG11rrgOe	1	t	2026-05-10 13:27:21.998629+00	\N	2026-05-01 17:11:29.323219+00	172.18.0.1	0	\N
\.


--
-- Data for Name: validations; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.validations (id, document_id, validator_id, validator_name, validated_at, comment, decision, version_letter, signature_hash, is_locked, created_at, updated_at) FROM stdin;
1	2	1	Admin	2026-05-01 18:43:10.973275+00	correct	APPROUVÉ	A1	988d452a6543fed54f6da83f143150f6c50c4706989a6ea82a11de072f48ee5b	t	2026-05-01 18:43:10.973275+00	2026-05-01 18:43:10.973275+00
2	3	3	Reviewer	2026-05-03 10:57:18.043327+00		APPROUVÉ	-	311fc33c14da1b24a43fa40a027bb154ca2739bb5e98a1e66c9b34b384da629c	t	2026-05-03 10:57:18.043327+00	2026-05-03 10:57:18.043327+00
3	4	3	Reviewer	2026-05-03 10:57:31.45137+00		APPROUVÉ	-	8f98127ac05554272a004e2aa4fd26bf06fd0bf3b3eeed0a348dd699b7960d39	t	2026-05-03 10:57:31.45137+00	2026-05-03 10:57:31.45137+00
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: smq_app
--

COPY public.versions (id, document_id, version_letter, file_path, file_name, file_size, mime_type, change_summary, created_at, created_by, sharepoint_link) FROM stdin;
1	2	-	02_PROCESSUS_SUPPORT/Manager_Sante_Securite_Travail/TR0001_Trame_-.pdf	TR0001_Trame_-.pdf	110471	application/pdf	Version initiale	2026-05-01 17:26:19.892033+00	\N	\N
2	2	A	02_PROCESSUS_SUPPORT/Manager_Sante_Securite_Travail/TR0001_Trame_A.pdf	TR0001_Trame_A.pdf	110471	application/pdf	test	2026-05-01 17:28:10.21874+00	2	\N
3	2	A1	02_PROCESSUS_SUPPORT/Manager_Sante_Securite_Travail/TR0001_Trame_A1.pdf	TR0001_Trame_A1.pdf	110471	application/pdf	ttttt	2026-05-01 17:35:09.862233+00	2	\N
4	3	-	02_PROCESSUS_SUPPORT/Manager_Sante_Securite_Travail/PR_Procedures/PR0001_Procedure_-.pdf	PR0001_Procedure_-.pdf	110471	application/pdf	Version initiale	2026-05-01 18:36:27.19572+00	\N	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=yb3CNw
5	4	-	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/TR_Trames/TR0002_Trame_-.pdf	TR0002_Trame_-.pdf	110471	application/pdf	Version initiale	2026-05-01 21:00:59.373113+00	\N	\N
6	5	-	02_PROCESSUS_SUPPORT/Maitriser_Achats_Logistique/PR_Procedures/PR0002_Procedure_-.pdf	PR0002_Procedure_-.pdf	110471	application/pdf	Version initiale	2026-05-01 21:05:15.828924+00	\N	\N
7	6	-	02_PROCESSUS_SUPPORT/Manager_Sante_Securite_Travail/GU_Guides/GU0001_Guide_-.pdf	GU0001_Guide_-.pdf	110471	application/pdf	Version initiale	2026-05-01 21:09:16.440759+00	\N	\N
9	8	-	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_Travail/GU_Guides/GU0002_Guide_-.pdf	GU0002_Guide_-.pdf	110471	application/pdf	Version initiale	2026-05-03 09:56:59.916292+00	\N	\N
10	7	A	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/TR_Trames/TR0003_Trame_A.pdf	TR0003_Trame_A.pdf	110471	application/pdf	ttesstt	2026-05-03 09:58:02.250825+00	2	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=p0Qkuc
8	7	-	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/TR_Trames/TR0003_Trame_-.pdf	TR0003_Trame_-.pdf	110471	application/pdf	Version initiale	2026-05-02 10:29:31.701291+00	\N	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=p0Qkuc
11	8	A	01_PROCESSUS_STRATEGIQUE/Gerer_Infrastructure_Environnement_Travail/GU_Guides/GU0002_Guide_A.pdf	GU0002_Guide_A.pdf	110471	application/pdf	tt	2026-05-03 10:07:47.188957+00	2	\N
12	7	A1	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/TR_Trames/TR0003_Trame_A1.pdf	TR0003_Trame_A1.pdf	110471	application/pdf	test	2026-05-04 08:12:28.099569+00	2	\N
13	9	-	02_PROCESSUS_SUPPORT/Manager_Motiver_Ressources/TR_Trames/TR0004_Trame_-.pdf	TR0004_Trame_-.pdf	110471	application/pdf	Version initiale	2026-05-06 09:47:03.511795+00	\N	\N
14	9	A	02_PROCESSUS_SUPPORT/Manager_Motiver_Ressources/TR_Trames/TR0004_Trame_A.pdf	TR0004_Trame_A.pdf	110471	application/pdf	test version	2026-05-06 09:47:43.411161+00	1	\N
15	7	A2	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/TR_Trames/TR0003_Trame_A2.pdf	TR0003_Trame_A2.pdf	110471	application/pdf	tett	2026-05-06 13:40:43.369863+00	1	\N
16	10	-	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/GU_Guides/GU0003_Guide_-.pdf	GU0003_Guide_-.pdf	110471	application/pdf	Version initiale	2026-05-06 14:19:05.111441+00	\N	\N
17	10	A	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/GU_Guides/GU0003_Guide_A.pdf	GU0003_Guide_A.pdf	110471	application/pdf	te	2026-05-06 14:33:19.2701+00	2	\N
18	11	-	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/MA_Manuel/MN0001_Manuel_-.pdf	MN0001_Manuel_-.pdf	110471	application/pdf	Version initiale	2026-05-08 14:32:00.035322+00	\N	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=Gw5JIR
19	11	A	01_PROCESSUS_STRATEGIQUE/Fournir_Prestations_Service/MA_Manuel/MN0001_Manuel_A.pdf	MN0001_Manuel_A.pdf	110471	application/pdf	vvvvv	2026-05-08 14:50:40.842712+00	2	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=5Zymj6
20	12	-	02_PROCESSUS_SUPPORT/Piloter_l_Entreprise/TR_Trames/TR0005_Trame_-.pdf	TR0005_Trame_-.pdf	110471	application/pdf	Version initiale	2026-05-08 15:09:16.017493+00	\N	https://mohetn.sharepoint.com/:b:/s/SMQ_GED/IQCw9fXvmCrMT65qsgFIceznAeZplQtudkr6nikDw9WYLKs?e=ENuUZw
\.


--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.ai_query_logs_id_seq', 23, true);


--
-- Name: document_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.document_types_id_seq', 10, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.documents_id_seq', 12, true);


--
-- Name: folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.folders_id_seq', 464, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.logs_id_seq', 393, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.notifications_id_seq', 78, true);


--
-- Name: processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.processes_id_seq', 16, true);


--
-- Name: reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.reset_tokens_id_seq', 2, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: security_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.security_incidents_id_seq', 31, true);


--
-- Name: status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.status_id_seq', 207, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.users_id_seq', 26, true);


--
-- Name: validations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.validations_id_seq', 3, true);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: smq_app
--

SELECT pg_catalog.setval('public.versions_id_seq', 20, true);


--
-- Name: ai_query_logs ai_query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_pkey PRIMARY KEY (id);


--
-- Name: doc_code_sequences doc_code_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.doc_code_sequences
    ADD CONSTRAINT doc_code_sequences_pkey PRIMARY KEY (type_code, process_code);


--
-- Name: document_types document_types_code_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_code_key UNIQUE (code);


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);


--
-- Name: documents documents_doc_code_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_doc_code_key UNIQUE (doc_code);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: processes processes_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.processes
    ADD CONSTRAINT processes_pkey PRIMARY KEY (id);


--
-- Name: reset_tokens reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.reset_tokens
    ADD CONSTRAINT reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: reset_tokens reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.reset_tokens
    ADD CONSTRAINT reset_tokens_token_key UNIQUE (token);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: security_incidents security_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_pkey PRIMARY KEY (id);


--
-- Name: status status_name_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_name_key UNIQUE (name);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (id);


--
-- Name: token_blacklist token_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.token_blacklist
    ADD CONSTRAINT token_blacklist_pkey PRIMARY KEY (jti);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: validations validations_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_logs_created; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_ai_logs_created ON public.ai_query_logs USING btree (created_at DESC);


--
-- Name: idx_ai_logs_user; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_ai_logs_user ON public.ai_query_logs USING btree (user_id);


--
-- Name: idx_incidents_detected_at; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_incidents_detected_at ON public.security_incidents USING btree (detected_at DESC);


--
-- Name: idx_incidents_severity; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_incidents_severity ON public.security_incidents USING btree (severity);


--
-- Name: idx_incidents_status; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_incidents_status ON public.security_incidents USING btree (status);


--
-- Name: idx_logs_action; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_logs_action ON public.logs USING btree (action);


--
-- Name: idx_logs_created_at; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_logs_created_at ON public.logs USING btree (created_at DESC);


--
-- Name: idx_logs_document_id; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_logs_document_id ON public.logs USING btree (document_id);


--
-- Name: idx_logs_severity; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_logs_severity ON public.logs USING btree (severity);


--
-- Name: idx_notif_unread; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_notif_unread ON public.notifications USING btree (user_id, is_read);


--
-- Name: idx_notif_user_id; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_notif_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_reset_tokens_token; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_reset_tokens_token ON public.reset_tokens USING btree (token);


--
-- Name: idx_token_blacklist_expires; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_token_blacklist_expires ON public.token_blacklist USING btree (expires_at);


--
-- Name: idx_validations_decision; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_validations_decision ON public.validations USING btree (decision);


--
-- Name: idx_validations_document_id; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_validations_document_id ON public.validations USING btree (document_id);


--
-- Name: idx_validations_validator_id; Type: INDEX; Schema: public; Owner: smq_app
--

CREATE INDEX idx_validations_validator_id ON public.validations USING btree (validator_id);


--
-- Name: ai_query_logs ai_query_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- Name: documents documents_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: documents documents_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.document_types(id);


--
-- Name: folders folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.folders(id) ON DELETE CASCADE;


--
-- Name: logs logs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: logs logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reset_tokens reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.reset_tokens
    ADD CONSTRAINT reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: security_incidents security_incidents_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: security_incidents security_incidents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: validations validations_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: validations validations_validator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_validator_id_fkey FOREIGN KEY (validator_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: versions versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: versions versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: smq_app
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO smq_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO smq_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO smq_app;


--
-- PostgreSQL database dump complete
--

\unrestrict 3fNsgiXngXub7esHvIxjvcA7AlAhHnLxPk5ndGoNM6pZkqoAmIgDueyvisDDwO8

